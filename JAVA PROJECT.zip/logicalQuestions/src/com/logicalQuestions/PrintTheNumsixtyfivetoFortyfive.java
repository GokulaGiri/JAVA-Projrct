package com.logicalQuestions;

public class PrintTheNumsixtyfivetoFortyfive {

	public static void main(String[] args) {
		

	}

}
