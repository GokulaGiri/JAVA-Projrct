package methodes.comNonStaticMethode;

public class PercentageCalculate {
	int m1, m2, m3, m4,m5;	
	void getMarks(int a1, int a2, int a3, int a4, int a5){
	m1=a1;
	m2=a2;
	m3=a3;
	m4=a5;
	m5=a5;
	}
	
	int getTotal(){
		 
	int total= m1+m2+m3+m4+m5;
	System.out.println("Tota ->" + total);
	return total;	
		
	}
	double getPercentage(int total){
		double per= (total*100)/500;
		System.out.println("Percentage ->" +per);
		return  per;
	}
	
	void getGrade(double per){
		if (per>=75) {
			System.out.println("A1 Grade");
		}
		else if(per>=65&&per<75){//not less than 65 and not more than 75
			System.out.println("A2 Grade");
		}
		else if(per>=55&& per<65){
			System.out.println("B1 Grade");
		}
		else if(per>=45 && per<55){
			System.out.println("b2 Grade");
		}
		else{
			System.out.println("C Grade");
		}
	}
	public static void main(String[] args) {
		PercentageCalculate pr = new PercentageCalculate();
		pr.getMarks(66, 65, 66, 66, 64);
		int total =pr.getTotal();
		 double per =pr.getPercentage(total);
		 pr.getGrade(per);
	}


}