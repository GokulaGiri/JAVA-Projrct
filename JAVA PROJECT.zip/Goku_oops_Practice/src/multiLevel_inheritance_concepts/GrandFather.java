package multiLevel_inheritance_concepts;

public class GrandFather{
void m1(){
	System.out.println("GrandFather Class m1 methode");
}
}
class Parent extends GrandFather{
	void m2(){
		System.out.println("Parent Class m2 methode");
	}
}
class Child extends Parent{
	void m3(){
		System.out.println("Child Class m3 methode");
	}
}