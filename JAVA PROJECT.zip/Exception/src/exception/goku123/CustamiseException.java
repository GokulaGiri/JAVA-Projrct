package exception.goku123;

class TooYoungException extends RuntimeException {
	TooYoungException(String msg){
		super(msg);
	}
}
class TooOldException extends RuntimeException{
	TooOldException(String msg){
		super(msg);
	}
}





public class CustamiseException {

	public static void main(String[] args) {
		int age =15;
		if(age<18){
			throw new TooYoungException("Your Age is very Small");
		}else if(age>50){
			throw new TooOldException("your age is very Old");
		}else{
			System.out.println("You can Happly marride");
		}

	}

}
