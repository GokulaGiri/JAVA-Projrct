package Set_demo;
import java.util.Set;

public class LinkedHashSet {
	public static void main(String[] args) {
		
		Set<String> languages = new java.util.LinkedHashSet<>();  // insertion order is Preserved  and Set is as it is follow
		languages.add("chemesrty");  
		languages.add("Physics");
		languages.add("math");
		languages.add(" English");
		System.out.println(languages);
		//System.out.println(languages.remove("math"));
	//	System.out.println(languages.contains("English"));
	//	System.out.println(languages.size());
	//	System.out.println(languages.isEmpty());
	//	languages.clear();
	//	System.out.println(languages);
		for (String els : languages) {
			System.out.println(els);
			
		}
		
		
		
		
		
		
	}

}
