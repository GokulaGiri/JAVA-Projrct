package polymorphisum;

public class MainTest1Test3 {
	public static void main(String[] args) {
		Test3 t3 = new Test3();
		t3.s1();
		t3.s2(5, 5);
		t3.s3(5, 6, 7);
	
		System.out.println("*****");
t3.getlanguage();
System.out.println(t3.language);
	

}
}