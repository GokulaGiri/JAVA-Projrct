package stringpack;

public class Demo2 {
	
	public static void main(String[] args) {
		
		String str =" i Love My Mom and Dad";
		System.out.println("The given String ="+str);
		str=str.toLowerCase();
		System.out.println("After converting lowercas ="+str);
		str=str.toUpperCase();
		System.out.println("After converting uppercas= "+str);
		///uppercas
		
	}	
}