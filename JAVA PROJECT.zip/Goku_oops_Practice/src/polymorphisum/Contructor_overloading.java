package polymorphisum;

public class Contructor_overloading {
	Contructor_overloading(){
		System.out.println("zero argument list");
	}
	Contructor_overloading(int a,int b){
		System.out.println("two argument list");
	}

	Contructor_overloading(int a,int b,int c){
		System.out.println("three argument list");
	}
}
