package com.conditionalStatements;

public class Gokula {

	public static void main(String[] args) {
 int a = 20;
 int b = 10;
 char o = '+';
 
 if (o=='+') {
	System.out.println(a+b);
}else if (o=='-'){
	System.out.println(a-b);
}else if (o=='*'){
	System.out.println(a*b);
}
else if (o=='/'){
	System.out.println(a/b);
}else if (o=='%'){
	System.out.println(a%b);
}else{
	System.out.println("invalid oprator");
}
 

	}

}
