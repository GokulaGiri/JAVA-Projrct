package placemene_pack;

public class Enum_demo {
	//enum season{winter, summer, rainy}
	enum Weekdays{sunday,mon,tues, when, thur, fri, sat}
public static void main(String[] args) {
	
for (Weekdays w : Weekdays.values())
{
	 System.out.println(w);
}	

System.out.println(Weekdays.valueOf("sunday").ordinal());

System.out.println(Weekdays.valueOf("mon").ordinal());
System.out.println(Weekdays.valueOf("tues").ordinal());

System.out.println(Weekdays.valueOf("when").ordinal());
System.out.println(Weekdays.valueOf("thur").ordinal());
System.out.println(Weekdays.valueOf("fri").ordinal());
System.out.println(Weekdays.valueOf("sat").ordinal());
}
}
