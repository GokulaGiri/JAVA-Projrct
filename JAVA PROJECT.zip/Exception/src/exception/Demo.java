package exception;

public class Demo {
	public static void main(String[] args) {
		  SayHello  ();
	}
	public static void SayHello (){
		SayGoodMornig();
	}
	public static void SayGoodMornig(){
		System.out.println(" Hello ALL" + "GOOD mornig");
	//	System.out.println(10/0);
		try {
	System.out.println(10/0);
		
	}
	catch (Exception e){
		System.out.println(10/1);
	}
			
	}		
			
			
}		
			
			
			
			
			
			
	

