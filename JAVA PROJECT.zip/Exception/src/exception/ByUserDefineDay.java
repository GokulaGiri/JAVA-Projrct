package exception;

	
	class YouCanNotVote extends RuntimeException{
		
		YouCanNotVote(String msg){
		
			
		super(msg);
	}
	}
	
	public class ByUserDefineDay {
	
	
	
	public static void main(String[] args) {
		
		int age =15;
		
		if(age<18){
			
		throw new YouCanNotVote(" your age is below 18.");
		
			
		}else{
			
			System.out.println("You can not vote.");
		}
		
	}

}
