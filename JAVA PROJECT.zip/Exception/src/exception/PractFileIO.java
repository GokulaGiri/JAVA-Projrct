package exception;

import java.io.File;
import java.io.IOException;

public class PractFileIO {
	public static void main(String[] args) {
		//create a file
		
		File  file =new File("test.text");
		try {
			file.createNewFile(); //error throgh karta hai esliye try & catch se help se handle karte hai
			System.out.println("File is created ");
		} catch (IOException e) {
	
			e.printStackTrace();
		} 
		
		
		// add data to the file
		
		
		//read data from file
		
		
		
		
		
		
		
		
		
		
	}

}
