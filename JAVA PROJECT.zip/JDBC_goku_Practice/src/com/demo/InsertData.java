package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertData {
	public static void main(String[] args) throws Exception {
		
		System.out.println("Step 1");
		Class.forName("com.mysql.jdbc.Driver");
		// step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
		//step 3
		Statement stm =con.createStatement();
		String sql="insert into team values(7,'ram')";
		//step 4 
	int ss=	stm.executeUpdate(sql);
	System.out.println(ss);
		
	}
	
}

