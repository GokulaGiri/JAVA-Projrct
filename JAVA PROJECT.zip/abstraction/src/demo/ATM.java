package demo;

public  abstract class ATM {
	
	abstract void withdraw();
	
	abstract void Deposites();
	abstract void checkBalance();
	
	void getTodaysDate(){
		System.out.println("17/06/2022");
	}
	
}
class SBIATM extends ATM{

	@Override
	void withdraw() {
		// TODO Auto-generated method stub
		System.out.println(" SBI ATM withdraw method");
	}

	@Override
	void Deposites() {
		// TODO Auto-generated method stub
		System.out.println("SBI ATM Deposites method ");
	}

	@Override
	void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("SBI ATM checkBalance method ");
	}
}
	

class CBIATM extends ATM{
	
	
//	void getTodaysDate(){
	//	System.out.println("17/06/2022");
	//}


	@Override
	void withdraw() {
		// TODO Auto-generated method stub
		System.out.println(" CBI ATM withdraw method");
	}
	

	@Override
	void Deposites() {
		// TODO Auto-generated method stub
		System.out.println(" CBI ATM Deposites method");
	}

	@Override
	void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println(" CBI ATM checkbalance method");
	}
	
}
