package placemene_pack;

import java.util.Scanner;

public class PracticeVowelsIfElse {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("enter a given  of character");
		
		char ch = sc.next().charAt(0);
		
	if (ch=='a'||  ch=='e'||  ch=='i'||  ch=='o'||  ch=='u'|| ch=='A'||  ch=='E'|| ch=='I'||   ch=='O'||ch=='U') {
	System.out.println(" THE GIVEN CHARACTER IS VOWELS");
		
	}
	else
	{
		System.out.println("THE GIVEN CHARATCTER IS CONSONONTS");
	}
			
	
		
	}

}
