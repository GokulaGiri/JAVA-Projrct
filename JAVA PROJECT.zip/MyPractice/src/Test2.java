
public class Test2 {

	public static void main(String[] args) {
		// writre a program of  prime number
		int n=53;
		if (n<=1) {
			System.out.println("number is  not Prime");
			return;
		}
		int count=0;
		int i=1;
		while (i<=n/2) {
			if (n%i==0) {
				count++;
			}
			i++;
		}
		if (count>1) {
			System.out.println("number is Not Prime");
		}else{
			System.out.println("no is prime");
		}
	}

}
