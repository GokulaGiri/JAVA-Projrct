package linkedListDemo;

import java.util.LinkedList;
import java.util.List;

public class LinkedListTestStudent {

	public static void main(String[] args) {
		List<StudenDataInLinekdList > student = new LinkedList<>();
		student.add(new StudenDataInLinekdList("jay",99,11));
		student.add(new StudenDataInLinekdList("nayan",88,22));
		student.add(new StudenDataInLinekdList("pawan",77,33));
		student.add(new StudenDataInLinekdList("kiran",66,44));
	System.out.println(student);// give the memory Location
		
		for (StudenDataInLinekdList x : student) {
		
		x.display();// give the All student Data
		
		
		//}
		/*StudenDataInLinekdList nayan=	student.get(1);
		// give the specific student data by using index 
		nayan.name="Nayan Dhulgand";
		nayan.marks=888;
		nayan.rollNum=222;
		
		nayan.display();
		
		*/
	//	student.remove(0);
		//System.out.println(student);
	}
	}
}
