package com.logicalQuestions;

public class PrintTheNumOneToFiftyDivByThreeAdFive {

	public static void main(String[] args) {
		 // 1 to 50 divisible by 3 and 5
		for (int i =1; i <=50; i++) {
			if (i % 5==0 && i % 3==0) {
				System.out.println(i);
			}
		}
		

	}

}
