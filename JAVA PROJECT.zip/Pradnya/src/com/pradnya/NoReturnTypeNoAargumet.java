package com.pradnya;
// 
public class NoReturnTypeNoAargumet {
	void add(){
		int a = 10;
		int b = 20;
		System.out.println(a+b);
	}
public static void main(String[] args) {
	NoReturnTypeNoAargumet nr = new NoReturnTypeNoAargumet();
	nr.add();
	
}

}
