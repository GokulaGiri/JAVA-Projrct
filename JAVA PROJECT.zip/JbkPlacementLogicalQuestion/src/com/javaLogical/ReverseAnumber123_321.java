package com.javaLogical;

public class ReverseAnumber123_321 {

	public static void main(String[] args) {
		int n=8965;
		int rev=0,rem=0;
		while (n>0) {
			rem=n%10;
			n=n/10; // we can write heare 
			rev=(rev*10)+rem;
			//n=n/10;// we can also writr heare , n=n/10
		}
    System.out.println("the reverse of given number is ="+rev);
	}

}
