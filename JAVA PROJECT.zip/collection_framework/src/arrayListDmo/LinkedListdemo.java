package arrayListDmo;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class LinkedListdemo {
	public static void main(String[] args) {
		List<String> langauges = new LinkedList<>();
		
		langauges.add("c++");
		langauges.add("java");
		langauges.add("python");
		langauges.add("php");
		langauges.add("aws");
	//	System.out.println(langauges);
		
	//	System.out.println(langauges.get(2));
	//	System.out.println(langauges.size());
		
	//	System.out.println(langauges.isEmpty());
	////	langauges.remove(3);
		//System.out.println(langauges);
		//System.out.println(langauges.contains("java"));
	//	for (String language : langauges) {
		//	System.out.println(language);
		
		//}
		Collections.sort(langauges);
		System.out.println(langauges);
		Collections.reverse(langauges);
		System.out.println(langauges);
		
	}

}
