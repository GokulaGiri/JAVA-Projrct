package com.logicalQuestions;

public class NumberIsPalindromeOrNot {  
//palindrome number means original number is equal to reverese of that nuber 
	public static void main(String[] args) {
		int n=121,rev=0,sum=0,temp=n;
		while (n>0) {
			rev=n%10;
			sum=(sum*10)+(rev);
			n=n/10;
		}
		if (temp==sum) {
			System.out.println("the number is pallindrome");
		}else{
			System.out.println("the number is not pallindrome");
		}
	}

}
