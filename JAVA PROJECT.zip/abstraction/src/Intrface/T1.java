package Intrface;

public class T1 implements B {

	@Override
	public void m1() {
		System.out.println("GOOD MORNING");
		
	}

}
