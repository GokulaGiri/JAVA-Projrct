package methodes.comNonStaticMethode;

public class WithReturnTypeWithArgument {
	int m4(int a , int b){
		int c =20;
		return a+b+c;
		
	}
public static void main(String[] args) {
	
	WithReturnTypeWithArgument wr1 = new WithReturnTypeWithArgument ();
	int x= wr1.m4(10, 30);
	
	System.out.println(x);
}

}
