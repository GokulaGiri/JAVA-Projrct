package abstrac_pack;

public class Main1 {

	public static void main(String[] args) {
		CBIATM cbi = new CBIATM();
		cbi.checkbalance();
		cbi.deposit();
		cbi.withdraw();
		System.out.println("*******************");
		SBIATM sbi = new SBIATM();
		sbi.withdraw();
		sbi.checkbalance();
		sbi.deposit();
	}

}
