package stringpack;

public class DistingofString {
	public static void main(String[] args) {
		
	
String str ="ssdlc";
String temp ="";
for(int i = 0; i<str.length();i++)
{
	if(temp.indexOf(str.charAt(i))==-1)
	{
		temp=temp+str.charAt(i);
	}
}
System.out.println(temp);
System.out.println("Distinct character count  " +temp.length());
}
}