package com.conditionalStatements;

public class Rutuja {

	public static void main(String[] args) {
		int num1=22;
		int num2=8;
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println(num1 + "/" + num2 + "=" + (num1/num2));
		System.out.println(num1 +   "mod" + num2 + "=" + (num1%num2));
	}

}
