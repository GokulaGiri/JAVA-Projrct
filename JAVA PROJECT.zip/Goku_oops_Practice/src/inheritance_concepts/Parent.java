package inheritance_concepts;
// single inheritance:=  one child class extends one parent class
public class Parent {
	void m1(){
		System.out.println("Parent Class M1 Methode");
	}

}
class Child  extends Parent{
	void m2(){
		System.out.println("Child Class m2 Methode");
	}
}
