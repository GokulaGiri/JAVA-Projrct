package not_use_to_extends_world_inheratance;

public class Main {
	public static void main(String[] args) {
		P p1=new P();
		p1.m1();
		
		C c1=new C();
		c1.m2();		
	}

}
