package com.conditionalStatements;

public class Test {

	public static void main(String[] args) {
	//	boolean condition = false;
		boolean condition = true;
		
		System.out.println("if block blody Start");
		if(condition){
			System.out.println("if block body will execute");
		}
System.out.println("If block body Stop");
	}

}
