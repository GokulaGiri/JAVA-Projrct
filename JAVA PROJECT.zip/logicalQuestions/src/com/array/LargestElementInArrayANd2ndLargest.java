package com.array;

import java.util.Arrays;

public class LargestElementInArrayANd2ndLargest {

	public static void main(String[] args) {
		int a []= {75,1,65,89,25,3,5};
		System.out.println(" Array Elements Are before Sorting ");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]+ " ");
		}
		Arrays.sort(a);
		System.out.println("Arrays Element After Sorting ");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i] + " ");
		}
		System.out.println("Largest Elements in Array is "+ a[a.length-1]);
		System.out.println(" Second Largest Elements in Array is "+ a[a.length-2]);
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}