package com.conditionalStatements;

public class Main {

	public static void main(String[] args) {
		 boolean con = true;
		 System.out.println("start");
		 if (con) {
			System.out.println("if block body excute");
		}else{
		 System.out.println("else block body excute");
		}
	}

}
