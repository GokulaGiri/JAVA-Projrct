package com.logicalQuestions;

public class Pattern {

	public static void main(String[] args) {
		int r=5;
		for (int i = 1; i <=r; i++) {
			for (int j = 1; j<=i; j++) {
			System.out.print(" "+"*"+" ");	
			}
			System.out.println();
			
		}

	}

	public static Pattern compile(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
