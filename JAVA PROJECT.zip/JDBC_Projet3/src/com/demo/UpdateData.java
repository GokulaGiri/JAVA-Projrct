package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateData {

	public static void main(String[] args) throws ClassNotFoundException, Exception {
		int id =18;
		String name ="Geeta";
		System.out.println("Step _1");
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Step _2");
		Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
PreparedStatement pstm = con.prepareStatement("update team set name=? where id=?");
pstm.setInt(2, id);
pstm.setString(1,name);
int i =pstm.executeUpdate();
System.out.println(i+" record updated ");
	}

}
