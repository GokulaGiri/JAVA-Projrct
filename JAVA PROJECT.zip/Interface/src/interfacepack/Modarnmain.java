package interfacepack;

public class Modarnmain {
	public static void main(String[] args) {
		
		SBIModarnATM sbimod = new SBIModarnATM();
		
		sbimod.changepin();
		sbimod.checkbalance();
		sbimod.deposit();
		sbimod.withdraw();
		
	}

}

