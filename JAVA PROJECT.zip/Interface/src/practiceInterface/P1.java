package practiceInterface;

 interface P1 {
	 void m1 ();

}
 interface P2 {
void m2 ();
}
 class C implements P1,P2 {
	 public void m1(){
		 System.out.println("m1 methode from p1 interface");
	 }
	 public void m2(){
		 System.out.println("m2 methode from p2 interface");
	 }
 }