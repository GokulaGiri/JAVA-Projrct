package practiceInterface;

public interface ATM {
	
	public abstract void deposit();

	public abstract void withdraw();
	public abstract void checkbalance();
}
class SBIATM implements ATM{
	
public  void deposit(){
	System.out.println("SBIATM deposite methode");
}

public  void withdraw(){
	System.out.println("SBIATM withdraw methode");
}

public  void checkbalance(){
	System.out.println("SBIATM checkbalance methode");
}



}

class CBIATM implements ATM{
	
public  void deposit(){
	System.out.println("CBIATM deposite methode");
}

public  void withdraw(){
	System.out.println("CBIATM withdraw methode");
}

public  void checkbalance(){
	System.out.println("CBIATM checkbalance methode");
}



}




