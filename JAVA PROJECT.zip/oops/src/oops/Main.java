package oops;

public class Main {
public static void main(String[] args) {
	Poly2 x=new Poly2();
	x.m2();
	child c= new child();
	c.m2();
}
}
