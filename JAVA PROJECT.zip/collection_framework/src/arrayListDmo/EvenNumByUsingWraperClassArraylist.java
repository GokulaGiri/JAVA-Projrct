package arrayListDmo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EvenNumByUsingWraperClassArraylist {
	public static void main(String[] args) {
		//List<Integer  ==  Generic == generic me hum different data type data storeg karte hai
	//	List<Integer>  evenNumbe = new ArrayList<>();
		List<Integer>  FirstFourevenNumbe = new ArrayList<>();
		FirstFourevenNumbe.add(2);
		FirstFourevenNumbe.add(6);
		FirstFourevenNumbe.add(8);
		FirstFourevenNumbe.add(10);
		//System.out.println(evenNumbe);
		
	//	System.out.println(evenNumbe.get(2));
		
		//evenNumbe.remove(1);
	//	System.out.println(evenNumbe);
		//evenNumbe.add(78);
	//	System.out.println(evenNumbe);
	List<Integer> FirstEightEvenNum = new ArrayList<>(FirstFourevenNumbe)	;
	
	FirstEightEvenNum.add(12);
	FirstEightEvenNum.add(14);
	FirstEightEvenNum.add(16);
	FirstEightEvenNum.add(18);
	//System.out.println(FirstEightEvenNum);
	
//	FirstEightEvenNum.removeAll(FirstEightEvenNum); // remove all and add all cllection lete hai
	//System.out.println(FirstFourevenNumbe);
	
	//FirstFourevenNumbe.contains(2);
		//System.out.println(FirstFourevenNumbe.contains(2));
		//System.out.println(FirstFourevenNumbe.contains(200));
		 Collections.sort(FirstEightEvenNum);
		//System.out.println(FirstEightEvenNum);
		 Collections.reverse(FirstEightEvenNum);
		System.out.println(FirstEightEvenNum);
		
		for (Integer ele : FirstEightEvenNum) {
			System.out.println(ele);
		}
	}

}
