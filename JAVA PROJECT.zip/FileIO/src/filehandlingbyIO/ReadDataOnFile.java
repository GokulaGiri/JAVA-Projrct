package filehandlingbyIO;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class ReadDataOnFile {
	
	static void ReadDataFromFile (){
		try {
			FileReader fileReader = new FileReader("giri.text");
			Scanner sc = new  Scanner (fileReader);
			while(sc.hasNextLine()){
				System.out.println(sc.nextLine());
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	
	}
	
	
	public static void main(String[] args) {
	//	Add data and Read FILE
		// try {
		//	FileReader fileReader = new FileReader("giri.text");
		//	Scanner sc = new  Scanner (fileReader);
		//	while(sc.hasNextLine()){
				//System.out.println(sc.nextLine());
			//}
		//} catch (FileNotFoundException e) {
			
		//	e.printStackTrace();
		//}
		//*****************************************************************
		ReadDataOnFile.ReadDataFromFile();
	}

}
