package arrayListDmo;

public class ArrayListEmployeeDetail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
