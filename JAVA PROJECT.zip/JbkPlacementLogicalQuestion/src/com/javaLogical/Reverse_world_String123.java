package com.javaLogical;

import java.util.regex.Pattern;

public class Reverse_world_String123 {

	static String reverseWords(String str ){
		Pattern p =Pattern.compile("\\s");
		String result= " ";
		
		String temp[]=p.split(str);
		
		for (int i = 0; i < temp.length; i++) {
			if (i==temp.length-1) {
				result=temp[i]+result;
			} else {
     result =" "+temp[i]+result;
			}
		}
		
		return result;
		
	}
	public static void main(String[] args) {
		String s1="java by kiran instutute";
				System.out.println(reverseWords(s1));
		String s2="i love mango";
		System.out.println(reverseWords(s2));
	}

}
