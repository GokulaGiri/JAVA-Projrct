package placemene_pack;

import java.util.Scanner;

public class PracticeArrayrev {
	public static void main(String[] args) {
		
	//	array initialization
		
		int arr[]= new int [10];
		
		Scanner sc = new Scanner (System.in);
		System.out.println("enter a element of the array");
		
		for (int i = 0; i < arr.length; i++) {
			arr[i]=sc.nextInt();
		}
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i] + "");
			
		}
		System.out.println();
		System.out.println("array in reverse number");
		for(int i = arr.length-1;i>0; i--){
			System.out.println(arr[i] + "");
		}
		
		
	}

}
