package com.conditionalStatements;

public class CheckTheNumIsDivBytwoNum {

	public static void main(String[] args) {
		int n = 30;
		if(n%3==0 && n%5==0){
			System.out.println("the num is divisible by 3 & 5");
		}
		else{
			System.out.println("the num is not  divisible by 3 & 5");
		}
	}

}
