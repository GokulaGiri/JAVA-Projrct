package swappingpak;

public class demo {
	public static void main(String[] args) {
		
		int a =30, b=10,temp;
		System.out.println(" Before swapping of valur  a= "+a+ " and b="+b);
			// temp = a;
	//	a=b;
		//b= temp;
		
		a= a+b;
		b= a-b;
		a=a-b;
		System.out.println(" after swapping value of a = " +a+ " and b = "+b);
		
		
		
		
		
		
	}

}
