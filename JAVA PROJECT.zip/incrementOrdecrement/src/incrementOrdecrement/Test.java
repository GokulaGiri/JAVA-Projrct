package incrementOrdecrement;
//increment value
public class Test {
	
public static void main(String[] args) {
	
	int a =10;
	int b = 0;
	 b=++a; //preincrement:-  pahile increment karna bad me use karna
	 System.out.println(b);
	 System.out.println(a);
	
}
	

}
