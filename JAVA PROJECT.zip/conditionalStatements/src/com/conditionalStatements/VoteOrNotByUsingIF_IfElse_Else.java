package com.conditionalStatements;

public class VoteOrNotByUsingIF_IfElse_Else {

	public static void main(String[] args) {
		int age =19;
		if(age>=18){
			System.out.println("you can vote");
		}
		else{
			System.out.println("you can not vote");
		}

	}

}
