package placemene_pack;

public class Enum_dem {
	enum season {winter, summer, rainy}
public static void main(String[] args) {
	
	for(season s : season.values())
	
	{
		System.out.println(s);
	}
	System.out.println(season.valueOf("winter").ordinal());
	
	System.out.println(season.valueOf("rainy").ordinal());
}
	
}
