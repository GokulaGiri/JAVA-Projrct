package mapdemo;

import java.util.Map;

public class LinkedHashMap {
	public static void main(String[] args) {
		
		Map<Integer,  String>  students = new java.util.LinkedHashMap<>();
		students.put(11, "jay");
		students.put(22, "goku");
		students.put(33, "hari");
		students.put(44, "manik");
	System.out.println(students);
		
		System.out.println(students.get(22));
		System.out.println(students.size());
		System.out.println(students.isEmpty());
		System.out.println(students.containsKey(33));
		
			
			
		
		
	}

}
