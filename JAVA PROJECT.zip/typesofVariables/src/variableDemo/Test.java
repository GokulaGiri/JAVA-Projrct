package variableDemo;

class employe{
	static String  company ="jbk";//static variables  :- static variables deals with class
	String name = "jay";//non static variables
	double salary=12852;// non static variables
	
	int employId=120;// non static variables  :- non static variables deals with object 
}




public class Test {
	public static void main(String[] args) {
		System.out.println(employe.company);// static variables access by using classname
		
		employe e1=new employe();
		System.out.println(e1.name);// non static variables access by using object reference
		System.out.println(e1.salary);
		System.out.println(e1.employId);
	}

}
