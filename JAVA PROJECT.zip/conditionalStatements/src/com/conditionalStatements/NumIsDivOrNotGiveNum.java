package com.conditionalStatements;

public class NumIsDivOrNotGiveNum {

	public static void main(String[] args) {
		int n=9;
		if(n%3==0){
			System.out.println("num is divisible by 3");
		}else{
System.out.println("num is not divisible by 3");
	}

}
}