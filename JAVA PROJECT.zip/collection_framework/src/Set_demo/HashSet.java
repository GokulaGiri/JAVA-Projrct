package Set_demo;

import java.util.Set;

public class HashSet {
	public static void main(String[] args) {
	
	// 1)	Set languages = new java.util.HashSet(); // HashSet-- object   type of data hold 
		Set<String> languages = new java.util.HashSet<>();//HashSet-- string  type of data hold (2)
		languages.add("C++");
		
		languages.add("java+");
		languages.add("C");
		languages.add("pytyhon");
		//languages.add(10);
	///	languages.add(10.5);
		//System.out.println(languages);

		//System.out.println(languages.get (1));
		//we will give error message because  set doen't have get method ,set doesn't have index, unordered 
	
	//	languages.remove("java");
		//System.out.println(languages);
	//	System.out.println(languages.size());
	//	System.out.println(languages.contains("C++"));
		//System.out.println(languages .isEmpty());
		//languages.clear();
		System.out.println(languages);
		
		//1) for (Object object : languages) {// when we create object tent) 
		// 	1) System.out.println(object);
		
		for (String ele : languages) {
			System.out.println(ele);
			
		}
		}
		
				
	}


