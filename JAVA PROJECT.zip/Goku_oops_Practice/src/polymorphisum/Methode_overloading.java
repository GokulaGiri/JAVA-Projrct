package polymorphisum;

public class Methode_overloading {
	void m1 (int a, int b){
		
		System.out.println(a+b);
	}
	void m2 (int a, int b, int c){
		System.out.println(a+b+c);
	}
}
