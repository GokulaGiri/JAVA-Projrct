package polymorphisum;

public class Variable_overriding_main {

	public static void main(String[] args) {
		child  cl =new child ();
		cl.language();// method overriding
		cl.getStr();

	}

}
