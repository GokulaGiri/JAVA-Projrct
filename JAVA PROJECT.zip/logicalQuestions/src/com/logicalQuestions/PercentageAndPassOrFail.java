package com.logicalQuestions;

public class PercentageAndPassOrFail {

	public static void main(String[] args) {
		
	//	int m1,m2,m3,m4,m5;
	//	int m1=50;
		int m1=85,m2=96,m3=98,m4=100, m5=98;
				//m3=80,
				//m4=89, 
				//m5=90;double 
	int total  = m1+m2+m3+m4+m5;
	double  percenteg =  (total*100)/500;
	
	System.out.println(total);
	System.out.println(percenteg);

	if(percenteg>=35){
		System.out.println("pass");
	}else{
		System.out.println("FAIL");
	}
	}

}
