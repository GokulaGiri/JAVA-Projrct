package com.logicalQuestions;

public class PrimeNum {
	public static void main(String[] args) {
		int n=2;
		int sum=0;
		if (n<=1) {
			System.out.println("the given no is not prime ");
			return;
		}for (int i = 2; i <=n-1; i++) {
			if (n%i==0) {
				sum=sum+1;
			}
		}
		if (sum==0) {
			System.out.println("the given no. is prime");
		}else{
			System.out.println("the given no is not prime");
		}
	}

}

/*public static void main(String[] args) {
	int n=153;
	int rem=0;
	int sum=0;
	while (n>0) {
		rem=n%10;
		n=n/10;

		sum=sum+(rem*rem*rem);
		
	}
	System.out.println("the armstrong number :-"+sum);
}
*/