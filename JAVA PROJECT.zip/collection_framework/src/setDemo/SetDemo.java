package setDemo;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		Set <String>langauges = new HashSet<>();
		langauges.add("C");
		langauges.add("C++");
		langauges.add("10");
		langauges.add("10");
		langauges.add("C");
		langauges.add("java");
		langauges.add("python");
		langauges.add("PHP");
		langauges.add("SQL");
	//	System.out.println(langauges);/// insertion ordered is not preserved 
		System.out.println(langauges.size()); 
		/*langauges.remove("C++");
		System.out.println(langauges);
		System.out.println(langauges.isEmpty());
		System.out.println(langauges.contains("python"));
		/*langauges.clear();
		System.out.println(langauges); // remove all elements in array
		*/
for (String str : langauges) {
	System.out.println(str);
}
	}

}
