package abstrac_pack;

public  abstract class Test {
	
	abstract void wish();

}
class Demo extends Test{

	@Override
	void wish() {
		// TODO Auto-generated method stub
		System.out.println(" good evening ");
	}
	//void wish (){
			//System.out.println(" good evening ......");
		//}
}	
	
	
	

