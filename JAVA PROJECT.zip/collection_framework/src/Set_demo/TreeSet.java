package Set_demo;

import java.util.Set;

public class TreeSet {
	public static void main(String[] args) {
		Set<String> languages = new java.util.TreeSet<>();
		languages.add("C++");
		languages.add("java");
		languages.add("z");
		languages.add("python");
		System.out.println(languages); // Tree Set   Sorting element . with as its follow set
		//System.out.println(languages.remove("z"));
	//	System.out.println(languages);
		//System.out.println(languages.contains("java"));
		
	//	System.out.println(languages.size());
		////System.out.println(languages.isEmpty());
	//	languages.clear();
	//System.out.println(languages);
	for (String els : languages) {
		System.out.println(els);
	}	
		
		
		
	}

}
