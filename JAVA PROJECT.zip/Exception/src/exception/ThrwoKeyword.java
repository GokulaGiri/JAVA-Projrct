package exception;

public class ThrwoKeyword {
	public static void main(String[] args) {
		//System.out.println(10/0);
	
//	ArithmeticException
		throw new  ArithmeticException (" / zero");

}
}