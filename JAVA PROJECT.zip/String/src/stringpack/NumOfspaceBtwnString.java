package stringpack;

import java.util.Scanner;

public class NumOfspaceBtwnString {
	public static void main(String[] args) {


		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any string");
		String a = sc.nextLine();
		int sp = 0;
		int vowel_count =0;
		a=a.toLowerCase();
		int len = a.length();
		//I like mango 
		for (int i = 0; i<= a.length()-1; i++)
		{ //

			char ch = a.charAt(i);
			if(ch=='a' ||ch=='e' ||ch=='i' ||ch=='o' || ch=='u' )
			{
				vowel_count++;
			}

			//}
			if(ch==32)

			{
				sp=sp+1;
				//System.out.println("the number of spaces are " + sp);
			}
			//System.out.println("the number of spaces are " + sp);
		}
		System.out.println("vovels preset in string " + vowel_count); 
		System.out.println("the number of spaces are " + sp);
	}

}
