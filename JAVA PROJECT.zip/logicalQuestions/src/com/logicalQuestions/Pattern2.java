package com.logicalQuestions;

public class Pattern2 {

	public static void main(String[] args) {
		int r=5;
		int space =(r*2)+2;
		for (int i = r; i >=1; i--) {
			for (int L = i; L >=1; L--) {
				System.out.print("*");
			}
			for (int s = space; s >=1; s--) {
				System.out.print(" ");
			}
			for (int R = i; R >=1; R--) {
				System.out.print("*");
			}
			space=space-2;
			System.out.println();
			
		}
			
		}

	}


