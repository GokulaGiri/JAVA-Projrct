package abstraction_jbk;

public class Main {

	public static void main(String[] args) {
//		Demo d =new  Demo();// abstract class can not create object
//		d.wish();

		SBIATM sbi = new SBIATM();
		sbi.checkBalance();
		sbi.changePin();
		sbi.deposit();
		sbi.withDraw();
		
		System.out.println("******************");
		
		CBIATM cbi = new CBIATM();
		cbi.checkBalance();
		cbi.changePin();
		cbi.deposit();
		cbi.withDraw();
	}

}
