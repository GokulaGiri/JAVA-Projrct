package com.conditionalStatements;

public class TestElseIF {

	public static void main(String[] args) {
		boolean con = false;
		
		System.out.println("if bolck body start");
		if(con){
			System.out.println("if block Body execute");
		}else{
			System.out.println("if block body will note execute");
		}

	}

}
