package practiceInterface;

public class ManiPreactice {
	
	public static void main(String[] args) {
		
		
		SBIATM sbi =new SBIATM();
		sbi.checkbalance();
		sbi.deposit();
		sbi.withdraw();
		
		
		
		System.out.println();
		
		CBIATM cbi =new CBIATM();

		cbi.checkbalance();
		cbi.deposit();
		cbi.withdraw();
	}
	

}
