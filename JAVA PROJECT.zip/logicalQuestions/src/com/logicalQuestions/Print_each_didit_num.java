package com.logicalQuestions;

public class Print_each_didit_num {

	public static void main(String[] args) {
		
		
		}

	}


