package com.rutuja;

public class Rutuja {

	public static void main(String[] args) {
		System.out.println("Hello");

	}

}
