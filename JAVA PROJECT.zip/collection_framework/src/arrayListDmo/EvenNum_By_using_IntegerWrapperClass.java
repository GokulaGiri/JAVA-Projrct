package arrayListDmo;

import java.util.ArrayList;
import java.util.List;

public class EvenNum_By_using_IntegerWrapperClass {

	public static void main(String[] args) {
		List<Integer> evenNumber=new ArrayList<>();
		
		evenNumber.add(2);
		evenNumber.add(4);
		evenNumber.add(6);
		evenNumber.add(8);
		evenNumber.add(10);
		//System.out.println(evenNumber);
		
		List<Integer> FirstTenEvenNum= new ArrayList<>(evenNumber);
		FirstTenEvenNum.add(12);
		FirstTenEvenNum.add(14);
		FirstTenEvenNum.add(16);
		FirstTenEvenNum.add(18);
		FirstTenEvenNum.add(20);
		System.out.println(FirstTenEvenNum);
		 
		

	}

}
