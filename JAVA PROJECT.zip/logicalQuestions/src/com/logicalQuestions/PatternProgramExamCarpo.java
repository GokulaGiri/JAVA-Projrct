package com.logicalQuestions;

public class PatternProgramExamCarpo {

	public static void main(String[] args) {
		int n=5; //rows // prefer odd no.
		int x=n;
		int y=n;
		for (int i = 1; i <=n; i++) {
			for (int j = 1; j <n*2; j++) 
				{
					if (j<=x) {
						System.out.print(j+"");
					}else if(j>=y){
						System.out.print(n*2-j+"");
					}else{
						System.out.print(" ");
					}
						
				}
				System.out.println();
				x--;
				y++;
			}
		}
		

	}


