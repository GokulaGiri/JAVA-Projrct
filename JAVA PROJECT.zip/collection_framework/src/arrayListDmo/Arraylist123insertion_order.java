package arrayListDmo;

import java.util.ArrayList;
import java.util.List;
/*
 * add();
 * addAll();
 * remove();
 * removeAll();
 * isEmpty();
 * size();
 * get();
 * voidClear();
 * 
;;
; */
public class Arraylist123insertion_order {

	public static void main(String[] args) {
	List<String> langvages = new ArrayList<>();
	langvages.add("C");//0
	langvages.add("c++");//1
	langvages.add("java");//2
	langvages.add("Pyathon");//3
	langvages.add("PHP");//4
	System.out.println(langvages);
	langvages.remove(1);
	System.out.println(langvages);
	

	}

}
