package hierarchical_inheritance;



class P {
	 void m1 (){
		 System.out.println("parent class m1 methode");
	 }
}
		 
		 class C1 extends P{
			 void m2 (){
				 System.out.println("child class C1 m2 methode");
			 }
		 }
		 
		 class C2 extends P{
			 void m2 (){
				 System.out.println("child class C2 m3 methode");
			 }
		 }
		 
		 
	 
		 
	 



