package com.javaLogical;

public class DigitInWord {

	public static void main(String[] args) {
		int n=9;
		if (n==0) {
			System.out.println("Zero");
		} else if(n==1) {
System.out.println("One");
		}else if(n==2) {
System.out.println("two");
		}else if(n==3) {
System.out.println("three");
		}else if(n==4) {
System.out.println("four");
		}else if(n==5) {
System.out.println("Five");
		}else if(n==6) {
System.out.println("six");
		}else if(n==7) {
System.out.println("seven");
		}else if(n==8) {
System.out.println("eight");
		}else if(n==9) {
System.out.println("nine");
		}else if(n==10) {
System.out.println("Ten");
		}else{
			System.out.println("invalid Digit");
		}

	}

}
