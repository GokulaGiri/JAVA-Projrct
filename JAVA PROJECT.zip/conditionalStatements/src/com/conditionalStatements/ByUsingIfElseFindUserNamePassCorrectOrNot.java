package com.conditionalStatements;

public class ByUsingIfElseFindUserNamePassCorrectOrNot {

	public static void main(String[] args) {
		String UserName="jay";
		String Password ="123";
		if(UserName=="jay" && Password=="123"){
			System.out.println("Welcome You Are Login");
		}else{
			System.out.println("Sorry You Can't Login");
		}

	}

}
