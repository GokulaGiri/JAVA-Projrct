package placemene_pack;

import java.util.Arrays;

public class LargestAndSecondLarNumArray {
	public static void main(String[] args) {
		
		int arr []={3,67,24,5,10};
		System.out.println("before sorting array elemt");
	for (int i = 0; i < arr.length; i++) {
		System.out.println(arr[i]+ "");
	}
		
		Arrays.sort(arr);
		
		System.out.println(" after sorting arry element");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i] +"");
		}
		System.out.println("Largest Elemet of array is " +arr[arr.length-1] );
		System.out.println(" Second Largest Elemet of array is " +arr[arr.length-2] );
	}

}
