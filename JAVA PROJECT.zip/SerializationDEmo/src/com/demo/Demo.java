package com.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
 
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class SerializationTest implements Serializable{
	int i=10;
	int j=20;
}


public class Demo {
	
	public static void main(String[] args) throws IOException {
		SerializationTest s1=new SerializationTest();
		System.out.println("Serialization started ");
		FileOutputStream fos =new FileOutputStream("C:\\Users\\HP\\Desktop\\Serial\\goku.txt ");

		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(s1);
		System.out.println("Serialization ended ");
		
		System.out.println("Deserisation Started");
		FileInputStream  fis = new FileInputStream("C:\\Users\\HP\\Desktop\\Serial\\goku.txt ");
		
	}

	

}