package com.logicalQuestions;

import java.util.Scanner;

public class By_using_OR_Operator_ifElse_Vowels_Consonant {
public static void main(String[] args) {
	System.out.println(" enter the given character ");
	Scanner sc =new Scanner (System.in);
char ch =sc.next().charAt(0);
if (ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U') {
	System.out.println("the given character is Vowels");
} else {
System.out.println("The given character is Consonant");
}
	
	

}
}
	
	











/*public static void main(String[] args) {
System.out.println("Enter the Given Character ");
Scanner sc = new Scanner (System.in);
char ch = sc.next().charAt(0);
if (ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='U') {
	System.out.println("The Given Character is Vowel");
}else{
	System.out.println("The Given Character is Consonant");
}
*/