package com.logicalQuestions;

public class By_using_if_else_Vowel_or_Consonant {

	public static void main(String[] args) {
		char ch ='b';
		
		if(ch=='a'){
			System.out.println("a is Vowels");
		}else if(ch=='e'){
			System.out.println("e is Vowels");
		}else if(ch=='i'){
			System.out.println("i is Vowels");
		}else if(ch=='o'){
			System.out.println("o is Vowels");
		}else if(ch=='u'){
			System.out.println("u is Vowels");
		}else if(ch=='A'){
			System.out.println("e is Vowels");
		}else if(ch=='E'){
			System.out.println("e is Vowels");
		}else if(ch=='I'){
			System.out.println("e is Vowels");
		}else if(ch=='O'){
			System.out.println("e is Vowels");
		}else if(ch=='U'){
			System.out.println("e is Vowels");
		}else{
			System.out.println("the Given Character is Consonant");
		}
			
		

	}

}
