package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		int id =14;;
		//String name ="ss";
	System.out.println("Step-1");
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("Step -2");
	Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
	PreparedStatement pstm = con.prepareStatement("delete from team where id = ?");
	pstm.setInt(1, id);
	int i =pstm.executeUpdate();
	System.out.println(i+ "record deleted ");
	
 
	}

}
