package methodes.comNonStaticMethode;

public class WithReturnTypeNoArgument {
	int m3 (){
		int  a=30;
		int b=20;
		return (a+b);
		
	}
public static void main(String[] args) {
	
	WithReturnTypeNoArgument w1 = new WithReturnTypeNoArgument ();
	System.out.println(w1.m3());
}
}
