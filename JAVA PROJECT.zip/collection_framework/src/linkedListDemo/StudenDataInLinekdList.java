package linkedListDemo;

public class StudenDataInLinekdList {

	
		
		String name;
		double marks;
		int rollNum;

	
	public StudenDataInLinekdList(String name,double marks,int rollNum){
		this.name=name;
		this.marks=marks;
		this.rollNum=rollNum;
	
	}
	void display(){
		System.out.println("Student Name is : " + name);
		System.out.println("Student marks is : " + marks);
		System.out.println("Student rollNum is : " + rollNum);
		System.out.println("**********************************************");
	}
	@Override
	public String toString() {
		return "StudenDataInLinekdList [name=" + name + ", marks=" + marks + ", rollNum=" + rollNum + "]";
	}
	
}

