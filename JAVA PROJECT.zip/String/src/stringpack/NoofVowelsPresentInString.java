package stringpack;

import java.util.Scanner;

public class NoofVowelsPresentInString {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		System.out.println("enter a string");
		String str = sc.nextLine();
		for (int i = 0; i < args.length; i++) {
			
		}
	}

}


















