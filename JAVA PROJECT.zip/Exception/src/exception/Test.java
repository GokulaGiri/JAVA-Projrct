package exception;

public class Test {
	public static void main(String[] args) {
		
		SayHello();
	}
	 public static void SayHello(){
		 SayGoogMornig();
	 }
	 public static void SayGoogMornig(){
		 System.out.println("Hello all " + " Good Morning");
		 System.out.println(10/0);
	 }	
	
}