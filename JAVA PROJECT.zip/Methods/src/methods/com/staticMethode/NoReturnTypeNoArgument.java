package methods.com.staticMethode;

public class NoReturnTypeNoArgument {
	static  void m1 (){
		 int a =10;
		 int b = 20;
		 System.out.println(a+b);
	 }
public static void main(String[] args) {
	//NoReturnTypeNoArgument n1 = new NoReturnTypeNoArgument();
	NoReturnTypeNoArgument.m1();
}
}
