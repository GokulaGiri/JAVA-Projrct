package placemene_pack;

public class String_palindrome {
	
	public static void main(String[] args) {
	
		String str = "madam";
		   
		StringBuffer strbuf = new StringBuffer(str);
		strbuf.reverse();
		
		String rev = new String(strbuf);
		
		System.out.println(str+"------"+rev);
		if(str.equals(rev))   /// Object class 
			System.out.println(" palindrome ");
		else
			System.out.println(" not palindrome ");
		
	
	
	}
}
