package mapdemo;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TreeeMapDemo {
	public static void main(String[] args) {
		
		
				
		Map<Integer, String> students =	 new LinkedHashMap<>();
		
		students.put(60,"kajal");
		students.put(50,"janvi");
		students.put(99,"reva");
		students.put(55,"rupali");
		
		
		System.out.println(students);
	}

}
