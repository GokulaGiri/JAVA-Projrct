
public class Test {

	public static void main(String[] args) {
		// write a program of even number
		int a=8;
		if (a%2==0) {
			System.out.println("number is even");
		}else{
			System.out.println("number is odd");
		}
	}

}
