package methods.com.staticMethode;

public class WithReturnTypeWithArgument {
	 static int m3(int a, int b){
		 int c = 10;
		 return (a+b+c);
	 }
	 public static void main(String[] args) {
		// WithReturnTypeWithArgument wr = new WithReturnTypeWithArgument();
		 int x = WithReturnTypeWithArgument.m3(20, 30);
		 System.out.println(x);
	}
}

