package placemene_pack;

import java.util.Scanner;

public class ReverseArray {
	public static void main(String[] args) {
		
		// initialise array
		int arr[] = new int[10];
		
				System.out.println(" Enter the elemet of an aaray");
				
				Scanner sc = new Scanner (System.in);
				
				for (int i = 0; i < arr.length; i++) {
					arr[i]=sc.nextInt();
					
				}
				for (int i= 0; i< arr.length; i++){
					System.out.println(arr[i] + " ");
				}
				System.out.println();
				System.out.println("Array in Reverse Order");
				
				//loop through the array in reverse order
				
			for (int i =  arr.length -1 ; i>0;i--) {
				System.out.println(arr[i]+ "");
			}
			

}
}