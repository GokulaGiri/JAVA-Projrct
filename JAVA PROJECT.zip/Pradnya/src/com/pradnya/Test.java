package com.pradnya;

public class Test {
public static void main(String[] args) {
	int a=10;
	int b=20;
	int sum=a+b;
	int sub=b-a;
	int mul=a*b;
	int div=b/a;
	System.out.println("addition=" +sum);
	System.out.println("substraction=" +sub);
	System.out.println("multiplication=" +mul);
	System.out.println("division=" +div);
}
}
