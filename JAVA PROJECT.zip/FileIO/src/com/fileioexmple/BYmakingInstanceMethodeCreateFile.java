package com.fileioexmple;

import java.io.File;
import java.io.IOException;

public class BYmakingInstanceMethodeCreateFile {
	
	 static void createnewfile(String FileName){
		// this mesthode will be create a new file 
		File file = new File(FileName);
		try {
			file.createNewFile();
			System.out.println("File is created");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		BYmakingInstanceMethodeCreateFile abc = new BYmakingInstanceMethodeCreateFile();
//abc.createnewfile("Bhagvat.txt");
		BYmakingInstanceMethodeCreateFile.createnewfile("xyz.txt ");
	}

}
