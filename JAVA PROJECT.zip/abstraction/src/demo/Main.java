package demo;

public class Main {
	
	public static void main(String[] args) {
		
		SBIATM sbi = new SBIATM ();
		sbi.withdraw();
		sbi.Deposites();
		sbi.checkBalance();
		sbi.getTodaysDate();
		System.out.println();
		
		
	CBIATM cbi = new CBIATM ();
		cbi.withdraw();
		cbi.Deposites();
		cbi.checkBalance();
		cbi.getTodaysDate();	
		
		
	}

}
//abstract void withdraw();

//abstract void Deposites();
//abstract void checkBalance();
