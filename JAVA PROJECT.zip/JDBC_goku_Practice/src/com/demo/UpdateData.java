package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class UpdateData {
	public static void main(String[] args) throws Exception {
		int id=7;
		String name ="bhagwat";
		//int nupid;
		//String name ="gokula";
		System.out.println("Step 1");
		Class.forName("com.mysql.jdbc.Driver");
		// step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
		//step 3
		PreparedStatement ps =con.prepareStatement("update  team set name =? where id =?");
	
	ps.setString(1, name);
	ps.setInt(2, id);
	
int i=	ps.executeUpdate();
System.out.println(i+" Records updated");
	
	 /*PreparedStatement stmt=con.prepareStatement("update emp set name=? where id=?");  
stmt.setString(1,"Sonoo");//1 specifies the first parameter in the query i.e. name  
stmt.setInt(2,101);  
  
int i=stmt.executeUpdate();  
System.out.println(i+" records updated");  
	*/
	}
	
}

