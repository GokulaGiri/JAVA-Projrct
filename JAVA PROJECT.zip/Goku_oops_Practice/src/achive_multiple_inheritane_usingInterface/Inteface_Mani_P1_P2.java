package achive_multiple_inheritane_usingInterface;

public class Inteface_Mani_P1_P2 {

	public static void main(String[] args) {
		 C c =new C ();
		 c.m1();
		 c.m2();

	}

}
