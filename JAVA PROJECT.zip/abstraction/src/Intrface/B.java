package Intrface;

public interface B {
	void m1 ();

}
