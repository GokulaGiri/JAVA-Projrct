package com.jbk.students;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class connection {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		System.out.println(1);
		Class.forName("com.mysql.jdbc.Driver");
		 String url = "jdbc:mysql://localhost:3306/student";
		String user = "root";
		String password = "root";
		System.out.println(2);
		Connection connection=DriverManager.getConnection(url, user, password);
		System.out.println(3);
Statement statment		=connection.createStatement();
System.out.println(4);
String sql = "select * from employe";
ResultSet resultSet = statment.executeQuery(sql);
while (resultSet.next()) {
	String id = resultSet.getString(1);
	String name = resultSet.getString(2);
	String city = resultSet.getString(3);
	String salary = resultSet.getString(4);
	System.out.println(id);
	System.out.println(name);
	System.out.println(city);
	System.out.println(salary);
	
	
}
resultSet.close();
statment.close();
connection.close();

/*
 * 	
 */
	}

}
