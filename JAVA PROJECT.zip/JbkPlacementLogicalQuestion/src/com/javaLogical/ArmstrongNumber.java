package com.javaLogical;

public class ArmstrongNumber {
public static void main(String[] args) {
	int n=152;
	int sum=0;
	int rem=0;
	int temp;
	temp=n;
	while (n>0) {
	rem=n%10;
	n=n/10;
	sum=sum+(rem*rem*rem);
	}
	if (sum==temp) {
		System.out.println("the number is Armstrong = " +sum);
		
	}else {
		System.out.println("the number is not Armstrong number = "+ sum);
	}
	
}
}
