package placemene_pack;

public class Static_non_static_concept {
	
	int a=500;
	static  int b=120;
	static
	{
	System.out.println(" i am in static block");
	System.out.println(b);
	}
	static void display ()
	{
		System.out.println(" i am in static methode");
		System.out.println(b);
	}
	void show()
	{
		System.out.println("i am in non static methode");
		System.out.println(a);
		System.out.println(b);
	}
	public static void main(String[] args) {
		System.out.println(" i am in main methode ");
		
		Static_non_static_concept obj = new Static_non_static_concept();
		obj.display();
		obj.show();
	}
}
