package com.javaLogical;

public class fabonasiseSeries {
// fabonacies serirs means add first number into second number that is result tis resule add into again previois number 
	public static void main(String[] args) {
		//  0 1 1 2 3 5 8 13 21 34
		int n1=0;
		int n2=1;
		int length =8;
		System.out.println(n1+"\n"+n2);
		for (int i = 0; i < length; i++) {
			int n3=n1+n2;
			System.out.println(n3);
			n1=n2;
			n2=n3;
		}
		
	}
}