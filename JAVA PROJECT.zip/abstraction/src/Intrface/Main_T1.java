package Intrface;

public class Main_T1 {
	public static void main(String[] args) {
		    T1 t = new T1();
		    t.m1();
	}

}
