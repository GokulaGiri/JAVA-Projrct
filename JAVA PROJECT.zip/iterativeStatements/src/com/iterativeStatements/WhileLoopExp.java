package com.iterativeStatements;

public class WhileLoopExp {

	public static void main(String[] args) {
		//print 1 to 10 number by using while loop
		int i =1;
		int n = 10;
		while(i<=n){
			System.out.println(i);
			i++;
		}
		

	}

}
