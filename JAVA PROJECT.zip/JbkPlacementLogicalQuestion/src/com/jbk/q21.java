package com.jbk;

 public  class q21  {
	 public static void main(String[] args) {
		
		  int a=30;
		 System.out.println(a);
	}
	 
	 
 }
 