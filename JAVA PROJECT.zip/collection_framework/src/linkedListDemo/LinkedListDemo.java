package linkedListDemo;


import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {

	public static void main(String[] args) {
		List<String> languages = new LinkedList<String>();
		languages.add("C");
		languages.add("C++");
		languages.add("Java");
		languages.add("python");
		languages.add("PHP");
		System.out.println(languages);
		System.out.println("Getting size of LinkdlistArray :-  "+languages.size());
		System.out.println(" getting specific index value :-" +languages.get(4));
		System.out.println(" c++ present or not :-" +languages.contains("C++"));
		languages.remove(2);
		System.out.println("remove java:- " +languages);
		System.out.println(" is array is empty :-" +languages.isEmpty());
		Collections.sort(languages);
		Collections.reverse( languages);
		System.out.println(languages);
		for (String string : languages) {
			System.out.println(string);
			
		}
		
		
	
		

	}

}
