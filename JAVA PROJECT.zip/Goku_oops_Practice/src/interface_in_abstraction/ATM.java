package interface_in_abstraction;

 public  interface ATM {
	public abstract void deposite();
	public abstract void checkBalance();
	public abstract void withdraw();
	public abstract void changePin();

}
 class SBIATM  implements ATM {

	@Override
	public  void deposite() {
		System.out.println("SBIATM deposit method");
		
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("SBIATM deposit method");
		
	}

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("SBIATM checkBalance method");
		
	}

	@Override
	public void changePin() {
		// TODO Auto-generated method stub
		System.out.println("SBIATM changePin method");
		
	}
	
	
}
 class CBIATM  implements ATM {

		@Override
		public  void deposite() {
			System.out.println("CBIATM deposit method");
			
		}

		@Override
		public void checkBalance() {
			// TODO Auto-generated method stub
			System.out.println("CBIATM deposit method");
			
		}

		@Override
		public void withdraw() {
			// TODO Auto-generated method stub
			System.out.println("CBIATM checkBalance method");
			
		}

		@Override
		public void changePin() {
			// TODO Auto-generated method stub
			System.out.println("CBIATM changePin method");
			
		}
		
		
	}