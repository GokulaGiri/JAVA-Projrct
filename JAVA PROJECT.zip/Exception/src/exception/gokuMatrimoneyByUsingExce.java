package exception;

class ToYoungAgeException extends RuntimeException{
	ToYoungAgeException(String msg){
		super (msg);
	}
}
public class gokuMatrimoneyByUsingExce {
	public static void main(String[] args) {
		int age =15;
		if(age<18){
			throw new ToYoungAgeException("your age is below 18 You can not marride");
		}else if(age>50){
			throw new ToYoungAgeException("your age is above 50 You can not marride");
		}else{
			System.out.println("congragulation  you have happily marride");
		}
	}

}
