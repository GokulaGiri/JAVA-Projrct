package oops;

public class Poly2 {
	String s1="hari";
void m2 (){
	System.out.println(s1);
}
}
class child extends Poly2{
	String s1 ="goku";
	void m2 (){
		System.out.println(s1);
	}
}
