package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ExecuteDataALLTable {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		System.out.println("Step 1");
		Class.forName("com.mysql.jdbc.Driver");
		// step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
		//step 3
		Statement stm =con.createStatement();
		//step 4 
		String sql="select * from team";
		// step 5
		ResultSet  rs =stm.executeQuery(sql);
		// step 6 
		
		while (rs.next()) {
			//step 7
			int id =rs.getInt(1);
			//int id =rs.getInt("id"); colum name se hi call kar sakate hai or number se hi call kar sakte hai
			String name =rs.getString(2);
			//String name =rs.getString("name");
			System.out.println(id+ " "+name);
		}
		
		

	}
	

}
