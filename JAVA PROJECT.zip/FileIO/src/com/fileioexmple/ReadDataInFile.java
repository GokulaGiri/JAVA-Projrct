package com.fileioexmple;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class ReadDataInFile {
	static void ReadDataToFile(String FileName){
		  try {
			FileReader myFile = new FileReader("manik.txt");
			Scanner sc = new Scanner(myFile);
			while(sc.hasNextLine()) {
				System.out.println(sc.nextLine());
			}
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
			
		}

	 }

	public static void main(String[] args) {
		
		ReadDataInFile re = new ReadDataInFile();
		re.ReadDataToFile("manik.txt");
	}

}
