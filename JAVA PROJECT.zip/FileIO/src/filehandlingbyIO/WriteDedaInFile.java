package filehandlingbyIO;

import java.io.FileWriter;
import java.io.IOException;

public class WriteDedaInFile {
	static void writeDataToFile(String FileName){
		FileWriter myFile;
		try {
			myFile = new FileWriter("manik.txt");
			myFile.write("jay Shree Ram \n Jay Hanuman ");
			System.out.println("data is write to file");
			myFile.close(); 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	

	public static void main(String[] args) {
		WriteDedaInFile wd = new WriteDedaInFile();
		wd.writeDataToFile("manik.txt");

	}

}
