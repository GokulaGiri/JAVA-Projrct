package filehandlingbyIO;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class AddData {
	// wright a data to the file
	static void WreiteData(String filename){
	try {
		FileWriter myfile = new FileWriter("giri.text") ;
		myfile.write("this is test deda");
		myfile.write("om sai ram /n jay sai ram");
		System.out.println("The file is add Data");
		myfile.close();
	} catch (IOException e) {
	
		e.printStackTrace();
	}
	}
	
	public static void main(String[] args) {
		
		AddData.WreiteData("giri.text"); 
		
	}

}
	
	
	
	
	
	
	
	
	
	
	
	
	
