package polymorphisum;

public class Method_overrriding {

}
