package exception;

public class PractOnTryCatchFinallyExcep {
	public static void main(String[] args) {
	
	
	try {
		
		System.out.println("TRY BLOCK EXICUTE");
		System.out.println(10/0);
	} catch (Exception e) {
		System.out.println("Catch Block Exicuted");
	}finally {
		System.out.println(" Finally Block Excuted");
	}
		
	}	
}	
		
		
		
		
		
		
		
		
		
	


