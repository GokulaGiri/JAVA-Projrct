package com.logicalQuestions;

public class FindTheGiveNumsMin {
//write the sum of one to ten number 
	public static void main(String[] args) {
		int n=10;
		int sum=0;
		for (int i = 1; i <=10; i++) {
			System.out.println(i);
			sum=sum+i;
		}
		System.out.println("the sum of one to ten num is :- " +sum);
	}

}
