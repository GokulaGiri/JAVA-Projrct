package polymorphisum;

public class Constructor_main {

	public static void main(String[] args) {
		 Contructor_overloading cr =new Contructor_overloading();
		 Contructor_overloading cr1 =new Contructor_overloading(1,2);
		 
		 Contructor_overloading cr2 =new Contructor_overloading(1,2,3);
		 // at the time of objet Creation constructor will be called

	}

}
