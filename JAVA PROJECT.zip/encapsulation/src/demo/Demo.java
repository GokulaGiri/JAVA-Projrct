package demo;

public class Demo {
	
	private double balance = 23654996.0;
	private String username = "gokula";
	//private long accountnum= 69857412365L;
	private String password ="jay123";
	private long accountnum= 69857412365L;
	
	 void getBalance(){
		if(username== "gokula" && password=="jay123"){
			System.out.println("balance is:  " +balance);
		}else{
			System.out.println("invalid user name & password");
		}
	}
	

}
