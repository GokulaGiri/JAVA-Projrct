package inheritance_concepts;

public class Constructor_inheritance {

}
