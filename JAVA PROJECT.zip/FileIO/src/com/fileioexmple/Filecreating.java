package com.fileioexmple;

import java.io.File;
import java.io.IOException;

public class Filecreating {

	public static void main(String[] args) {
		// CREATE a file
		File file = new File("Aai123.txt");
		try {
			file.createNewFile();
			System.out.println("file is created ");
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		

	}

}
