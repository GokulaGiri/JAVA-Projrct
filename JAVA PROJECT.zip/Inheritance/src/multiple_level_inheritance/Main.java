package multiple_level_inheritance;

public class Main {
	public static void main(String[] args) {
		
		CC cc=new CC();
	cc.m3();
	cc.m2();
	cc.m1();
		
		
	}

}
