package demoOperators;

public class Relational_Operator {
	public static void main(String[] args) {
		int a =10;
		int b =5;
		int c=10;
	c++;
	int b1 =c;
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(b1);
	
	
	
	
	
	
/*	if(a>b&&b>a){ // and  
	System.out.println("statment is true");
	}else{
		System.out.println("statmnet is fale");
	}
	*/
	
	}
}
