package com.logicalQuestions;

public class PrintTheNumOneToFourtFiveMultiplOfSeven {

	public static void main(String[] args) {
//  1  to 45
		for (int i = 1; i <=45; i++) {
			if (i%7==0) {
				System.out.println(i);
				
			}
		}

	}

}
