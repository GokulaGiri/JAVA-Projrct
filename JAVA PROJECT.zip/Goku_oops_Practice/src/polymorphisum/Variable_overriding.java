package polymorphisum;

//public class Variable_overriding {
//
//}
class parent{
	String str = "nilam"; // variable overriding
	void language(){// method overriding
		System.out.println("java");
	}
}
class child extends parent {
	String str ="Nayan"; /// variable overriding
	void language(){// method overriding
		System.out.println("python");
		
	}
	public void getStr(){
		System.out.println(str);
	}
}
