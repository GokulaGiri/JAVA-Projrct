package arrayListDmo;

import java.util.ArrayList;
import java.util.List;

public class ArraylistByUsingWrapperClass {
	public static void main(String[] args) {
		
		
		List<String> Langauges= new ArrayList<>();
		
		Langauges.add("Java");
		Langauges.add("	C++");
		Langauges.add("aws");
		Langauges.add("Python");
		Langauges.add("php");
		System.out.println(Langauges);
		
		Langauges.remove(1);
		System.out.println(Langauges);
		Langauges.get(3);
		System.out.println(Langauges.get(3));
	}

}
