package com.jbk.students;
import java.sql.*;
public class CheckConnection {
	static Connection con=null;
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	String url ="jdbc:mysql://localhost:3306/student";
	String user ="root";
	String password ="root";
		
		
		Class.forName("com.mysql.jdbc.Driver");
		  con = DriverManager.getConnection(url, user, password);
		if(con!=null){
			System.out.println("connection is establish");
			System.out.println(con);
						}
		}
		
	}


