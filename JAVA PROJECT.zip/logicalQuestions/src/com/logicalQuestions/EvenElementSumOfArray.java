package com.logicalQuestions;

public class EvenElementSumOfArray {

	public static void main(String[] args) {
		int n []={1,2,3,4,5};
		int sumE=0;
		int sumO=0;
		for (int i : n) {
			if(i%2==0){
				sumE=sumE+i;
			}	
		}
		System.out.println("sum of even number is = " + sumE);	
				
		for (int i : n) {
			if(i%2==1){
				sumO=sumO+i;
			}	
		}
		System.out.println("sum of Odd number is = " +sumO);	
					
		
		
		
		
	}

}
