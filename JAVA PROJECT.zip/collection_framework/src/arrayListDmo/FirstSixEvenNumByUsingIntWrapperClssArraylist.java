package arrayListDmo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FirstSixEvenNumByUsingIntWrapperClssArraylist {

	public static void main(String[] args) {
		List<Integer> firstThreeEvenNum = new ArrayList<>();
		firstThreeEvenNum.add(2);
		firstThreeEvenNum.add(4);
		firstThreeEvenNum.add(6);
		
		List<Integer> firstSixEvenNum = new ArrayList<>(firstThreeEvenNum);
		// one collection is added to other collection.
		List<Integer> nextThreeEvenNum = new ArrayList<>();
		nextThreeEvenNum.add(8);
		nextThreeEvenNum.add(10);
		nextThreeEvenNum.add(12);
		// using addAll(); method 
		firstSixEvenNum.addAll(nextThreeEvenNum);
		System.out.println(firstSixEvenNum);
		
	//	firstSixEvenNum.removeAll(nextThreeEvenNum);
		//System.out.println("FirstThreeNumis /n "+firstSixEvenNum);
	//	System.out.println(firstSixEvenNum.contains(2));// the given value is present or not present it will checked by contains();method
		System.out.println(firstSixEvenNum.get(1));
		System.out.println(firstSixEvenNum.size());
		System.out.println(firstSixEvenNum.isEmpty());
		Collections.sort(firstSixEvenNum);
		Collections.reverse(firstSixEvenNum);
		System.out.println("reverse Descending  Ordenr :-" +firstSixEvenNum);
		for (Integer integer : firstSixEvenNum) {
			System.out.println(integer);
		}
	}

}
