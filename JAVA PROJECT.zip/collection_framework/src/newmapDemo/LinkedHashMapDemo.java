package newmapDemo;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapDemo {

	
	public static void main(String[] args) {
		Map<Integer, String>  students = new LinkedHashMap<Integer, String>();
		
		students.put(66, "jay ");
		students.put(55, "amay ");
		students.put(44, "radha ");
		students.put(33, "krushna ");
		students.put(22, "megha ");
		System.out.println(students);

	}

}
