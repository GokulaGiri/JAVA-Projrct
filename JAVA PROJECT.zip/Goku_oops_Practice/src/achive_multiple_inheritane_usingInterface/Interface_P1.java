package achive_multiple_inheritane_usingInterface;

public interface Interface_P1 {
	public abstract void m1();
	

}
 interface Interface_P2 {
	public abstract void m2();
	

}
 class C implements Interface_P1,Interface_P2 {

	
	public void m2() {
		System.out.println("Interface_P1 method m1");
		
	}

	
	public void m1() {
		System.out.println("Interface_P2 method m2");
		
		
	}
	 
 }
