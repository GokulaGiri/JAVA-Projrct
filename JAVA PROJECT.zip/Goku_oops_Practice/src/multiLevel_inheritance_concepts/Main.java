package multiLevel_inheritance_concepts;

public class Main {

	public static void main(String[] args) {
		Child ch = new Child();
		ch.m1();
		ch.m2();
		ch.m3();

	}

}
