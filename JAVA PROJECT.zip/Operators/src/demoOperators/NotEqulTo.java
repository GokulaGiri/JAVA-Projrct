package demoOperators;

public class NotEqulTo {
	public static void main(String[] args) {
		
		int a =10;
		int b =5;
		if(a!=b ||a==b){//||or operator one condition  
			System.out.println("statment is true");
			
		}else{
			System.out.println("statment is false");
		}
		
	}

}
