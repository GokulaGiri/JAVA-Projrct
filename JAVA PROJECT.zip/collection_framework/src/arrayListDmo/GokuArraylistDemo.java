package arrayListDmo;

import java.util.ArrayList;
import java.util.List;

public class GokuArraylistDemo {

	public static void main(String[] args) {
		List l1 = new ArrayList();
		
		l1.add("sai");
		l1.add(10);
		l1.add(20);
		l1.add(20);
		l1.add(true);
		l1.add(30);
		l1.add(10);
		System.out.println(l1 );
		//System.out.println(l1.get(4   ));//give specific ele
	//	l1.remove(3);
		//System.out.println(l1);//  remove perticular element 
		System.out.println(l1.size());// get the size of arraylist
		System.out.println(l1.isEmpty());
		l1.clear();
		System.out.println(l1);
		
	}
}
