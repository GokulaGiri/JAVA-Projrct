package placemene_pack;

import java.util.ArrayList;
import java.util.List;

public class ListPractice {
	
	public static void main(String[] args) {
		List l1 = new ArrayList();
		
		l1.add("gokula");
		l1.add(10);
		l1.add(20);
		l1.add(30.5);
		l1.add(40);
		
		System.out.println(l1);
		System.out.println(l1.get(3));
		
		l1.remove(2);
		System.out.println(l1);
		l1.add(80);
		System.out.println(l1);
		l1.addAll(l1);
	
		System.out.println(l1);
	}

	
}
