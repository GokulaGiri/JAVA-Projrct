package stringpack;

public class WhteSpaceRemoveInString {
	public static void main(String[] args) {
		String str ="My name is Gokula";
		System.out.println(str);
		str=str.replaceAll(" ","");
		System.out.println("After Removing WhiteSpace");
		System.out.println(str);
	}

}
