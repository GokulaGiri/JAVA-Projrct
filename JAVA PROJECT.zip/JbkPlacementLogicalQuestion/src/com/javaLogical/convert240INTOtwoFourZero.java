package com.javaLogical;

public class convert240INTOtwoFourZero {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
