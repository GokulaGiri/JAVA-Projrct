package com.iterativeStatements;

public class ForLoopExampla {

	public static void main(String[] args) {
		// print 1 to 10 number 
		int n=10;
		for (int i = 1; i <=n; i++) {
			System.out.println(i);
		}
		
		

	}

}
