package practiceInterface;

public class MultipleInheritanceMain {
	public static void main(String[] args) {
		
		C c = new C ();
		c.m1();
		System.out.println();
		c.m2();
		
		
		
	}

}
