package abstrac_pack;

public abstract class Test1 {
	abstract  void  withdraw();
	abstract  void  deposit();
	abstract  void  checkbalance();
}
class SBIATM extends Test1{

	@Override
	void withdraw() {
		System.out.println("SBIATM withdraw methode");
		
	}

	@Override
	void deposit() {
		System.out.println("SBIATM deposit Methode ");
		
	}

	@Override
	void checkbalance() {
		System.out.println("SBIATM checkbalance ");
		
	}
	
}
class CBIATM extends Test1{

	@Override
	void withdraw() {
		System.out.println("CBIATM withdraw methode");
		
	}

	@Override
	void deposit() {
		System.out.println("CBIATM deposit Methode ");
		
	}

	@Override
	void checkbalance() {
		System.out.println("CBIATM checkbalance ");
		
	}
	
}