package com.fileioexmple;

import java.io.FileWriter;
import java.io.IOException;

public class WriteAdataInFile {

	public static void main(String[] args) {
	// write a data to the  file
		try {
			FileWriter myFile = new FileWriter("manik.txt");
			myFile.write("this is data :- I am Gokula Giri ");
			System.out.println("Data is write to file ");
			myFile.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
