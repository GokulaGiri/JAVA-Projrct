package encapsulation123;

public class Test {
	private double balance =785956;
	private String username ="Goku";
	private String pass ="Goku@123";
	private  long AccountNum =9286954201L; 
	
	public  void getBalance(){
		if (username =="Goku" && pass == "Goku@123") {
			System.out.println(balance);
		}else{
			System.out.println("invalid username and password ");
		}
		
	}

}
