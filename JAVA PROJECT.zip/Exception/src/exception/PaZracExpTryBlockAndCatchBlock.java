package exception;

public class PaZracExpTryBlockAndCatchBlock {
	public static void main(String[] args) {
		SayHelo();
		
		
	}
	public static void SayHelo(){
		SayGoddMorning();
	}
public static void SayGoddMorning(){
	System.out.println("Hello All " + "Good MOrning");
	 try {
		System.out.println(10/0);
	} catch (Exception e) {
		System.out.println(10/1);
	}
	
	
	
	
	
	
	
		
	}


}
