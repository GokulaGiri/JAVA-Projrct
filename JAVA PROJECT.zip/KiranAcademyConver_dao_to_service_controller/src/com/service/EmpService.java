package com.service;

import java.util.ArrayList;

import com.model.teamindia;

public class EmpService {

	public void  getEmpInfo(){
		ArrayList<teamindia> al=new ArrayList<>();
	}
	
	
}
