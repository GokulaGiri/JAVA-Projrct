package incrementOrdecrement;

public class Dcrement {
	public static void main(String[] args) {
		//postincrement :- pahile use kare bad me increment kare
		int a =10;
		int b =0;
		b=a++;
		System.out.println(b);
		System.out.println(a);
		
	}

}
