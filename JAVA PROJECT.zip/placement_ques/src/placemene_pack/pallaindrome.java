package placemene_pack;

public class pallaindrome {
	
	
	public static void main(String[] args) {
	
		
			int n = 171 , rem, sum=0, temp;
			
			temp=n;
			while(n>0)
			{
				rem=n%10;
				sum=(sum*10)+rem;
				 n=n/10;
				
			}
			if(sum==temp)
				System.out.println("pallindrome");
			else
				System.out.println(" not pallindrome");
			
		
	}
}
		
		
		
		
		

		
		
	


