package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class InsertMultipleRecord {
	public static void main(String[] args) throws Exception {
		int id=9;
		
		String name ="gokula";
		System.out.println("Step 1");
		Class.forName("com.mysql.jdbc.Driver");
		// step 2
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
		//step 3
		PreparedStatement ps =con.prepareStatement("insert into team (id,name) values (?,?)");
	//ps.setInt(1, 8); // apan as hi karu shakto 
		ps.setInt(1, id);
	//ps.setString(2, "maya");
		ps.setString(2, name);
	ps.executeUpdate();
	
		
	}
	
}

