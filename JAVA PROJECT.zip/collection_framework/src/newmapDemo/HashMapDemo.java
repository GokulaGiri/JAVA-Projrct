package newmapDemo;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		Map<Integer, String> students= new HashMap<Integer, String>();
		
		students.put(11, "jay");
		students.put(22, "amay");
		students.put(33, "goku");
		
		students.put(44, "manik");
		System.out.println(students);
		
		System.out.println(" 22 key is present or not present " +students.containsKey(22));
		System.out.println(" GEt the 44 key details " +students.get(44));
		System.out.println(" Array is empty or not " +students.isEmpty());
		System.out.println("Size of the Araay is:- " + students.size());
		students.remove(33);
		System.out.println("remove 33 key  details from arraylist "+ students);
		students.clear();
		System.out.println(" delete all element in array "+ students);

	}

}
