package setDemo;

import java.util.Set;
import java.util.TreeSet;

public class SetDemoForTreeset {

	public static void main(String[] args) {
		Set <String>langauges = new TreeSet<>();
		langauges.add("java");
		langauges.add("C++");
		langauges.add("Python");
		langauges.add("PHP");
		langauges.add("C");
		langauges.add("A");
		langauges.add("Z");
		langauges.add("M");
		
		/*System.out.println(langauges);
		/*System.out.println(langauges.size());
		System.out.println(langauges.contains("M"));
		
		System.out.println(langauges.isEmpty());
		
		langauges.remove("Z");
		*/
		System.out.println(langauges);
		for (String str : langauges) {
			System.out.println(str);
		}

	}

}
