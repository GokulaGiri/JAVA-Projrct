package com.logicalQuestions;

public class Sum_of_array_By_using_forEachLoop {

	public static void main(String[] args) {
		int [] n ={1,2,3,4,5};
		int sum=0,pro=1,avg=0;
		
		for (int i : n) {
			
			
			sum=sum+i;
		}
		System.out.println("Sum of Array elemnet is :-"+ sum);
for (int i : n) {
			
			
			pro=pro*i;
		}
		System.out.println("Product of Array element is :-" + pro);
for (int i : n) {
			
			
			avg=avg+i;
		}
System.out.println("Average of Array element is :-"+avg/5);
	}

}
