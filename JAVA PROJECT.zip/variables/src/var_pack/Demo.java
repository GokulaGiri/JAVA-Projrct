package var_pack;

public class Demo {
	
	public static void main(String[] args) {
	// 1)	
	//	int a = 24;
		
	//	a=30;
	//	System.out.println(a); //ek hi valu print hongi jo modify hoe o
		
		//---------------------------------------------
		
	// 2)
		//int a = 24;
		
		//System.out.println(a);
		//a=30;
		//System.out.println(a);// esme two value print honge
		
		// 3)
		
	//	int A_B_12_C= 30;
		
	//	System.out.println(A_B_12_C);
		
		
		int A =20;
		int B = 20;
		int C = A+B;
		System.out.println(A+B+C);
		System.out.println(A+B);
		System.out.println(C);
		
		
		
		
		
	}

}
