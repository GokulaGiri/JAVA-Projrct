package abstraction_jbk;

 abstract public class Test {
	abstract void wish();
		
	

}
 class Demo extends Test{

	@Override
	void wish() {
	System.out.println("good evening");
		
	}
	
	
}