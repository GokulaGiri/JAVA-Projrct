package methods.com.staticMethode;

public class NoReyturnTypeWithArgument {
static	void m2 (int a ){
		double b =10.0d;
		float c = 20.0f;
		System.out.println(a+b+c);
	}
public static void main(String[] args) {
//	NoReyturnTypeWithArgument nr = new NoReyturnTypeWithArgument();
	//nr.m2(30);
	NoReyturnTypeWithArgument.m2(30);
}
}
