package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.model.teamindia;

public class EmpDao {
	
	ArrayList<teamindia>  getEmpInfo() throws Exception{
		System.out.println(1);
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(2);
		Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root","root" );
		System.out.println(3);
		Statement stm=con.createStatement();
		String sql ="select * from team";
	ResultSet rs=	stm.executeQuery(sql);
	System.out.println(4);
	teamindia e=new teamindia();
	ArrayList<teamindia> al=new ArrayList<>();
	while (rs.next()) {
		int id =rs.getInt(1);
		String name =rs.getString(2);
		e.setId(id);
		e.setName(name);
		//System.out.println(id+ " "+name);
		//System.out.println(e);
		al.add(e);
		System.out.println(al);
	}
	return al;


}}
