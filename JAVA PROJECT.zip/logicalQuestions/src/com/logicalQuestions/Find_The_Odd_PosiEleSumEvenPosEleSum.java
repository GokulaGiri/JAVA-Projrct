package com.logicalQuestions;

public class Find_The_Odd_PosiEleSumEvenPosEleSum {

	public static void main(String[] args) {
		int a[]={1,2,3,4,5};
int sum=0,even=0,odd=0;
int n=5;

System.out.print(" sum = ");
for (int i = 0; i < n; i++) {
	sum+=a[i];
	System.out.print(a[i]);
	if(i<4)
		System.out.print(" + ");
}
System.out.print(" = " + sum + " ");
System.out.print("\n sum of even position Element is ->");
for (int i = 0; i < a.length; i+=2) {
	even+=a[i];
	System.out.print(a[i]);
	if(i<4)
		System.out.print(" + ");
	
}
System.out.print(" = ");
System.out.print(even);

System.out.print("\n sum of odd position Element is ->");
for (int i = 1; i < a.length; i+=2) {
	odd+=a[i];
	System.out.print(a[i]);
	if(i<4)
		System.out.print(" + ");
}
System.out.print(" = ");
System.out.print(odd);

System.out.println(" \n************************* ");

System.out.print("\nEven Element:");
for (int i = 0; i < a.length; i++) {
	if (a[i]%2==0) {
		System.out.print(" "+a[i]+" ");
		
	}
	
}
System.out.println("\n*************");


System.out.print("odd Element:");
for (int i = 0; i < a.length; i++) {
	if (a[i]%2!=0) {
		System.out.print(" "+a[i]+" ");
	}
}

	}

}
