package by_using_interface_achive_multiple_inheritance;

public class Main {
	public static void main(String[] args) {
		
		
		C c= new C();
		c.m3();
		
		System.out.println("*************************");
		c.m4();
		
	}

}
