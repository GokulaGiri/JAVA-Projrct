package placemene_pack;

import java.util.Arrays;

public class PracScondLarAndLarArry {
	
		
	public static void main(String[] args) {
		
		int [ ]arr={10,90,60,45,20};
		System.out.println("Before sorting alement");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i] + "");
		}
		
		Arrays.sort(arr);
		System.out.println("After sorting Elrmrnt");
		for (int i = 0; i < arr.length; i++) {
			System.out.println(arr[i] +"");
		}
		
		System.out.println("largest number is array is " +arr[arr.length-1]);
		System.out.println("second largrst number is " +arr[arr.length-2]);
	}	
		
	}


