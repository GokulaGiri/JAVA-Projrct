package com.logicalQuestions;

public class Print_the_Num_onetoFourty_notDivByFour {
// the number 1 to 40  which is not divisible by   4 
	public static void main(String[] args) {
for (int i = 1; i <=40; i++) {
	if (i%4!=0) {
		System.out.println(i);
		
	}
	
}

	}

}
