package com.logicalQuestions;

import java.util.Iterator;

public class EnumSrasons {
	enum Weekdays{sunday,monday,tuesday,wenday,thursday,firday,saturday};
	public static void main(String[] args) {
		for (Weekdays w : Weekdays.values()) {
			System.out.println(w);
		}
	}
	
}




/*1)
 * enum Seasons{winter,summer,rainy}
public static void main(String[] args) {
	for (Seasons s : Seasons.values()) {
		System.out.println(s);
	}
}
*/

