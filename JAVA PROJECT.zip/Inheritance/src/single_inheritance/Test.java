package single_inheritance;

 class P {
	 void m1 (){
		 System.out.println("parent class m1 methode");
	 }
 }
		 
		 class C extends P{
			 void m2 (){
				 System.out.println("child class m2 methode");
			 }
		 }
		 
		 
	 


