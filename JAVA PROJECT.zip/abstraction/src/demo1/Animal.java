package demo1;

public class Animal  
	{  	 

	public static void main(String[] args) {
		System.out.println("hello");
	}
	}
