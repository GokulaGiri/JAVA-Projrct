package abstraction_jbk;

abstract public class ATM {

	abstract void deposit();
	abstract void checkBalance();
	abstract void changePin();
	abstract void withDraw();
}
class SBIATM extends ATM{

	@Override
	void deposit() {
	System.out.println("SBIATM deposit Method ");
		
	}

	@Override
	void checkBalance() {
		System.out.println("SBIATM checkBalance Method");
		
	}

	@Override
	void changePin() {
		System.out.println("SBIATM changePin Method");
		

		
	}

	@Override
	void withDraw() {
		// TODO Auto-generated method stub
		System.out.println("SBIATM withDraw Method");
		

		
	}
	
}
class CBIATM extends ATM{

	@Override
	void deposit() {
		// TODO Auto-generated method stub
		System.out.println("CBIATM deposit Method");
		
	}

	@Override
	void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("CBIATM checkBalance Method");
		
	}

	@Override
	void changePin() {
		// TODO Auto-generated method stub
		System.out.println("CBIATM changePin Method");
		
	}

	@Override
	void withDraw() {
		// TODO Auto-generated method stub
		System.out.println("CBIATM withDraw Method");
		
	}
	
}