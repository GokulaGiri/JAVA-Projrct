package abstrac_pack;

public class Main {
	
	public static void main(String[] args) {
		Demo d = new Demo ();
		d.wish();
	}
}
		
	


