package newmapDemo;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		Map<Integer, String> company = new TreeMap<Integer, String>();
		company.put(101, "Infosys");
		company.put(102, "Cpagemini");
		company.put(103, "HCL");
		company.put(104, "JBK");
		company.put(105, "Cognazant");
		
System.out.println("Get the All Element in Array :-"+company);
System.out.println(" specfic Key details is present or not :-"+ company.containsKey(104));
System.out.println(" Get the Specific Key Details :-"+company.get(102));
System.out.println("Is the Array is Empty :-" + company.isEmpty());
System.out.println("Size of the Aray is :-" + company.size());
company.remove(103);
System.out.println("delete the specific  element in array list :- " +company);
company.clear();
System.out.println("Dlete the all elemennt in in aaray List :-" +company);
	}

}
