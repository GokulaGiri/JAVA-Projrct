package polymorphisum;

public class Test {
// method overloading
void m1(){
	System.out.println("m1 methode  0 argument ");
}
	void m1(int a, int b){
		System.out.println("m1 method 2 argument");
		System.out.println(a+b);
	}
void m1(int a, int b , int c){
	System.out.println("m1 method 3 argument");
	System.out.println(a+b+c);
	//System.out.println("****************************");
}
	
//******************************************************************
// constructor overloading
Test(){
	System.out.println("zero argument constructor");
}
Test(int p,int q){
	System.out.println("two argument constructor");
	System.out.println(p+q);
}
Test(int p,int q , int r){
	System.out.println("three argument constructor");
	System.out.println(p+q+r);
}


public static void main(String[] args) {
	Test t = new Test();
	
	Test t2 = new Test(10,20);
	
	Test t3 = new Test(10,20,30);
	
	System.out.println("********************");
	t.m1();
	t.m1(1, 2);
	t.m1(1, 2, 3);
	
	//Test t1 = new Test();
	

	
}

}
