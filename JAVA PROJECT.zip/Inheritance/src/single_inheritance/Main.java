package single_inheritance;

public class Main {
	public static void main(String[] args) {
		
		//P p1 =new P();
	//	p1.m1();
		
		C c1 = new C();
		c1.m2();
		c1.m1();
		
		//single inherantce madhe single parent and single child aste
		//aapn parent class chi (m1)methode child class object  madhe writen karu shakto and child class chi method suddha 
		//
		
		
		
	}

}
