package com.logicalQuestions;

public class PyranmidDoubleTriangleIncreasingOrder {

	public static void main(String[] args) {
		
	        
	        int rows = 5;
	        int[] diff = {0,1,3,5,7,9};
	        int blank = 0;
	        int b = 0;
	        int temp;
	        
	        for(int i = rows; i >= 1; --i){
	            
	            blank = diff[b++];

	            if(blank == 0){
	               temp = i-1;
	            } else{
	                temp = i;
	            }
	            for(int j = 1; j <= i; j++){
	                
	                System.out.print(" "+ j + " ");
	            }
	        
	            for(int s = 0; s < blank; s++){
	                System.out.print("   ");
	            }
	            
	            for(int k = temp; k >= 1; --k){
	                System.out.print(" " + k + " ");
	            }
	            System.out.println();            
	        }
	    }
	
	}


