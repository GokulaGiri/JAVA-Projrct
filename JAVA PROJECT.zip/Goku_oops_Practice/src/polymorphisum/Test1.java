package polymorphisum;

public class Test1 {
	// variable overriding 
	String language = "java";
// method overriding
	void s1(){
		System.out.println("s1 method");
	}
	void s2(int a, int b){
		System.out.println("s1 method");
		//System.out.println(a+b);
	}
	void s3(int a, int b , int c){
		System.out.println("s1 method");
		//System.out.println(a+b+c);
	}
	
}
class Test3 extends Test1{
	// variable overriding 
	String language ="paython";
	// method overriding
	void getlanguage(){
		System.out.println(language);
	}
	void s1(){
		System.out.println("s1 modify method");
		System.out.println("0");
		
	}
	void s2(int a, int b){
		System.out.println("s2  modify method");
		System.out.println(a+b);
	}
	void s3(int a, int b , int c){
		System.out.println("s3  modify  method");
		System.out.println(a+b+c);
	}
	//*****************************
	
}