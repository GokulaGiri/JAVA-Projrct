package arrayListDmo;

import java.util.LinkedList;
import java.util.List;

public class StudentsDBLinkedlist {
	public static void main(String[] args) {
		List<StudentsUserDefinedData>  students = new  LinkedList<>();
		
		
		students.add(new StudentsUserDefinedData( " jay" , 55 ,11));
		
		students.add(new StudentsUserDefinedData( " maya" , 66 ,22));
		
		students.add(new StudentsUserDefinedData( " kurshana" , 77 ,33));
		
		students.add(new StudentsUserDefinedData( " janvi" , 88 ,44));
		
		
	/////	System.out.println(students);
		
	//	for (StudentsUserDefinedData student : students) {
		//student.disply();
		
			
		//}
		//StudentsUserDefinedData maya = new students.get(1);
		//maya.disply();
		StudentsUserDefinedData maya =	students.get(1);
		maya.disply();
	}

}
