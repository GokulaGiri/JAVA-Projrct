package mapdemo;

import java.util.HashMap;
import java.util.Map;

public class GokuMapDemo {

	public static void main(String[] args) {
	Map<Integer, String> students = new HashMap<Integer, String>();
	students.put(11, "jay");
	students.put(22, "nayan");
	students.put(33, "gokula");
	students.put(44, "manik");
	students.put(55, "ram");
	System.out.println(students);
	System.out.println(students.containsKey(22)); //true
	System.out.println(students.isEmpty());//false
	System.out.println(students.get(44));//mani
	students.remove(11);//remove jay from list
	System.out.println(students);

	}

}
