package com.manu_logical_Questin;

public class Area_of_Circle {

	public static void main(String[] args) {
		double radius=10;
		double pie= 3.14;
		double area =pie*radius*radius;
		System.out.println(area);

}
}
