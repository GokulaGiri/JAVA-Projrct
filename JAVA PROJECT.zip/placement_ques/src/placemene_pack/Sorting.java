package placemene_pack;

import java.util.Arrays;

public class Sorting {
	public static void main(String[] args) {
		
		int a []={15 ,20, 30, 67, 57 };
		
		System.out.println("before sorting element");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i] + " ");
			
		}
		Arrays.sort(a);
		System.out.println("after sorting element");
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i] + " ");
		}
		System.out.println("largest element in array " + a[a.length-1]);
		System.out.println(" Second largest element in array " + a[a.length-2]);
	}
	

}
