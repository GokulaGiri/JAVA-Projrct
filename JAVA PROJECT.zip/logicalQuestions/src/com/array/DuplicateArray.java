package com.array;

public class DuplicateArray {

	public static void main(String[] args) {
		int [] a =new int []{64,55,89,25,55,74,65,42,64};
System.out.println("Duplicate Array in given Array");
// search for duplicate array
for (int i = 0; i < a.length; i++) {
	for (int j = i+1; j < a.length; j++) {
		if (a[i]==a[j]) 
			System.out.println(a[j]);
		
	}
}
	}

}
