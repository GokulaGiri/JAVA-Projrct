
package interface_in_abstraction;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SBIATM sbi =  new SBIATM();
		sbi .changePin();
		sbi .checkBalance();
		sbi .deposite();
		sbi .withdraw();
		System.out.println();
		
		System.out.println("*************");
		
		System.out.println();
		CBIATM cbi =  new CBIATM();
		cbi .changePin();
		cbi .checkBalance();
		cbi .deposite();
		cbi .withdraw();
		
		

	}

}
