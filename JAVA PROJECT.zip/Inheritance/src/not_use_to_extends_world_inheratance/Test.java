package not_use_to_extends_world_inheratance;

class P {
	
	void m1(){
		System.out.println("parents class m1 methode");
	}

}
class C {
	void m2(){
		System.out.println("parents class m2 methode");
	}
}
