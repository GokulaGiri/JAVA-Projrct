package com.logicalQuestions;

public class Sum_pro_avg_of_Array {

	public static void main(String[] args) {
		int [] arr={1,2,3,4,5};
		int sum=0,pro=1,avg=0;
		int i;
		for(i=0;i<5;i++){
			sum=sum+arr[i];
		}
		System.out.println(" sum of array elements are :-" + sum);
		for(i=0;i<5;i++){
			avg=avg+arr[i];
		}
		System.out.println("average of array elements are " +avg/5);
		for(i=0;i<5;i++){
			pro=pro*arr[i];
		}
		System.out.println(pro);
	}

}
