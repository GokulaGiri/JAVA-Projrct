package exception;
import java.io.FilterInputStream;
 








		
		
		public class Manu {
			public static void main(String[] args) {
		
	}

}
