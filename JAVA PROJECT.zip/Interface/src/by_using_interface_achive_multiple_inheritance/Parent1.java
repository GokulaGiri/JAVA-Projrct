package by_using_interface_achive_multiple_inheritance;

 interface Parent1 {
  void m3 ();
		}

 interface Parent2 {
	 void m4 ();
 }		

 class C implements Parent1,Parent2{
	 
	 public  void m3(){
		 System.out.println("Parent1 interface class methode ");
	 }
	 public  void m4(){
		 System.out.println("Parent2 interface class methode ");
	 }
 }
 