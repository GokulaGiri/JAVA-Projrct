package com.logicalQuestions;

public class PracticeArmstrongNum {
	/*public static void main(String[] args) {
		int  n = 153;
		int sum = 0;
		int rem  = 0;
		while (n>0) {
			rem=n%10;
			n=n/10;
			sum= sum+(rem*rem*rem);
		}
		System.out.println("num is amstrong " +sum);
		
		
	}
*/
	
	public static void main(String[] args) {
		int n = 370;
		int rem =0; 
		int sum = 0;
		while (n>0) {
			rem = n%10;
			n= n/10;
			sum = sum +(rem* rem* rem);
			
		}
		System.out.println("number is aremstrong " + sum);
	}
}
