package mapdemo;

import java.util.HashMap;
import java.util.Map;
//package mapdemo;
public class HashMapdDemo {
	
	public static void main(String[] args) {
		
		Map<Integer, String> Students = new HashMap<>();
		
		Students.put(11, "jay");
		
		Students.put(22, "janvi");
		Students.put(33, "kajal");
		
		Students.put(44, "gokula");
		
		System.out.println(Students);
		
		//how to access specific value => using key 
		
		System.out.println(Students.get(22));
		
		
		Students.remove(11);
		System.out.println(Students);
	}

}
