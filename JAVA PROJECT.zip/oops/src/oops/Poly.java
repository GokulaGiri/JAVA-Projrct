package oops;

public class Poly {
//	Poly(){
//		System.out.println("0 args");
//	}
//	Poly(int a){
//		System.out.println("1 args :"+a);
//	}
//	Poly(int a, char b){
//		System.out.println("2 args :"+a+b);
//	}
	void add (){
		System.out.println(10+20);
	}
	void add (int a){
		System.out.println(a+20);
	}
	int add (int x,int y){
		return(x+y);
	}
	void add (char b, int g){
		System.out.println("char and int  "+b);
	}
public static void main(String[] args) {
	Poly p=new Poly();
//	Poly p1=new Poly(10);
//	Poly p2= new Poly(20, 'a');
	p.add();
	p.add(20);
	int f=p.add(20, 30);
	System.out.println(f);
	p.add('s', 50);
}
}
