package interfacepack;


public interface ModarnATM {
	
	void deposit();
	void withdraw();
	void changepin();
	void checkbalance();

}

  class SBIModarnATM implements ModarnATM{
	
	 public void deposit(){
	System.out.println(" SBIATM deposites methode");
	}

	 public void withdraw(){
			System.out.println(" SBIATM withdraw methode");
			} public void changepin(){
				System.out.println(" SBIATM changepin methode");
			}
			 public void checkbalance(){
					System.out.println(" SBIATM checkbalance methode");
					}


	
}
