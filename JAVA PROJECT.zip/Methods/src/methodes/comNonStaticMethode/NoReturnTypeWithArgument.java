package methodes.comNonStaticMethode;

public class NoReturnTypeWithArgument {
	void m2(int a ,int b){
	//	int b =20;
		int c = 10;
		System.out.println(a+b+c);
	}
public static void main(String[] args) {
	NoReturnTypeWithArgument  n2 = new NoReturnTypeWithArgument();
	n2.m2(30, 20);
}
}
