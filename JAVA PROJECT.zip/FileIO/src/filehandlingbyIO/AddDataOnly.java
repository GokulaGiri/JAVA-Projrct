package filehandlingbyIO;

import java.io.FileWriter;
import java.io.IOException;

public class AddDataOnly {
	public static void main(String[] args) {
		try {
			FileWriter myfile = new FileWriter("giri.text") ;
			myfile.write("this is test deda");
			System.out.println("The file is add Data");
			myfile.close();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		
	}

}
