package com.jbk.students;

import java.sql.*;

import javax.swing.plaf.synth.SynthScrollPaneUI;

public class PractCheckConnection {
	static Connection con = null;
	
	public static void main(String[] args) throws SQLException  {
		//exceptin handle 
		try{
		String url = "jdbc:mysql://localhost:3306/student";
		String user = "root";
		String password ="root";
		Class.forName("com.mysql.jdbc.Driver");
		 con=	 DriverManager.getConnection(url, user, password);
		if(con!=null){
			System.out.println("connection is establish");
			System.out.println(con);
		}
		}catch (Exception e1){
			System.out.println(e1);
	//	}catch (SQLException e2){
			//System.out.println("connection problem");
		}finally{
			con.close();
		}
	}
	
	

	

	

}
