package placemene_pack;

import java.util.Scanner;

public class PracticeVowelsUsingSwitchcase {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println(" enter the value of character");
		char ch = sc.next().charAt(0);
		switch (ch)
		{
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U':
		
			System.out.println(" the given character is vowels ");
		break;
		default:
			System.out.println("  the given charater is not vowels means consonat");
		
		
		}
	}

}
