package hirarchical_inheritance;

public class Main {

	public static void main(String[] args) {
		Class1 c1 = new Class1();
		c1.m1();
		c1.m2();
System.out.println("********"); 
Class2 c2= new Class2();
c2.m1();
c2.m3();

	}

}
