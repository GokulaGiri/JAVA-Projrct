package com.logicalQuestions;

public class StringIsPalindromeOrNot {

	public static void main(String[] args) {
		String str = "madam";
		StringBuffer strbuf = new StringBuffer(str);
		strbuf.reverse();
		if (strbuf.equals(strbuf)) {
			System.out.println("palindrome");
		}else{
			System.out.println("not palindrome");
		}
		
		
	}}
		/*String str = "madam";
		StringBuilder strbuf =new StringBuilder(str);
		strbuf.reverse();
		if (strbuf.equals(strbuf)) {
			System.out.println("string is Palindrome");
		}else{
			System.out.println("String is not Palindrome");
		}*/
	


