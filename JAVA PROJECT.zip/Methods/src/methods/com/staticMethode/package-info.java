/**
 * 
 */
/**
 * @author HP
 *
 */
package methods.com.staticMethode;