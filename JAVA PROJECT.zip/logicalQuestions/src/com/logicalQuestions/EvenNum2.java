package com.logicalQuestions;

public class EvenNum2 {

	public static void main(String[] args) {
		
		int n=2;
		if (n%2==0) {
			System.out.println("the number is even ");
		}else{
			System.out.println("the number is odd");
		}
		
	}

}
