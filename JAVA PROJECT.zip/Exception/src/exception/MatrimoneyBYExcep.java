package exception;
//by using  User defined data we create exception handling programme
class ToYoungAgeExceptoin  extends RuntimeException{
	ToYoungAgeExceptoin(String msg){
		super(msg);
	}
}
public class MatrimoneyBYExcep {
	public static void main(String[] args) {
		int age =15;
		if(age<18){
			throw new ToYoungAgeExceptoin("your age is very small");
		}else if (age>50){
			throw new ToYoungAgeExceptoin("your age is very old");
		}else{
			System.out.println("congragulatin  your profile is creat we can happily marride");
		}
		
		
		
	}
	

}
