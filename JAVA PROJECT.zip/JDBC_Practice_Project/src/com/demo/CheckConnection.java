package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;





public class CheckConnection {

	public static void main(String[] args) throws ClassNotFoundException, Exception {
		System.out.println("Step - 1");
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Step -2");
		Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
		System.out.println("Step- 3");
		
		Statement stm=con.createStatement();
		String sql="select * from team";
		ResultSet res =stm.executeQuery(sql);
		System.out.println("Step- 4");
		while(res.next()){
			int id=res.getInt(1);
			String name =res.getString(2);
			
			System.out.println(id+ " "+ name);
		}
		
}
}
