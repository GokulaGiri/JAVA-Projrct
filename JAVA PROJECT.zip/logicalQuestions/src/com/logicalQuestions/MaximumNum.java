package com.logicalQuestions;

public class MaximumNum {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=5;
		if (a>b) {
			System.out.println(a);
		}else if (b>c){
			System.out.println(b);
		}else{
			System.out.println();
		}

	}

}
