package var_pack;

public class Test {
	public static void main(String[] args) {
		 
		int a =20;
		float f = 2.5f;
		
		char c =  'a';
		
		boolean b = false;
		
		String s = " Hello Word";
		
		
		System.out.println(a);
		System.out.println(f);
		System.out.println(c);
		System.out.println(b);
		System.out.println(s);
		
		
	}

}
