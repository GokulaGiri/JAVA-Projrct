package com.javaLogical;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

 class SerializableTest implements Serializable {
	int i = 10;
	int j = 20;

}

 public class Demo {
	public static void main(String args[]) throws Exception {
		SerializableTest d1 = new SerializableTest();
		System.out.println("Serialization started");
		FileOutputStream fos = new FileOutputStream("C:\\Users\\HP\\Desktop\\Serial\\DemoT.txt");
		
                                                    	//	C:\Users\HP\Desktop\Serial
		// C:\\Users\\HP\\OneDrive\\Desktop\\DemoT.txt
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(d1);
		System.out.println("Serialization ended");
		
		System.out.println("Deserialization started");
		FileInputStream fis = new FileInputStream("C:\\Users\\HP\\Desktop\\Serial\\DemoT.txt");
		//C:\\Users\\HP\\OneDrive\\Desktop\\DemoT.txt"
		ObjectInputStream ois = new ObjectInputStream(fis);
		SerializableTest d2 = (SerializableTest) ois.readObject();
		System.out.println("Deserialization ended");
		System.out.println(d2.i + "................" + d2.j);
	}
}

/*output
Serialization started
Serialization ended
Deserialization started
Deserialization ended
10................20
*/
