package com.javaLogical;

public class SumOFDigit123_6 {

	public static void main(String[] args) {
		int n=1263;
		int sum=0,rem=0;
		while (n>0) {
			rem=n%10;
			n=n/10;
			sum=sum+rem;
		}
		System.out.println(sum);
}
}
/*
int n=1263;
int sum=0,rem=0;
while (n>0) {
	rem=n%10;
	n=n/10;
	sum=sum+rem;
	
	
}
System.out.println(sum);
	}

}
*/