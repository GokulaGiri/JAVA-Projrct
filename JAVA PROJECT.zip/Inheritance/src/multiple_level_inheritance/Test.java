package multiple_level_inheritance;



class P {
	 void m1 (){
		 System.out.println("parent class p m1 methode");
	 }
}
		 
		 class C extends P{
			 void m2 (){
				 System.out.println("child class C m2 methode");
			 }
		 }

		 class CC extends C{
			 void m3(){
				 System.out.println("child class CC m3 methode");
			 }
		 }
