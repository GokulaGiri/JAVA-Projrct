package com.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InserData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int id =21;
		String name="Aarchana";
		
		System.out.println("Step -1");
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Step -2");
		Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/teamindia", "root", "root");
		
		PreparedStatement pstm = con.prepareStatement("insert into team (id,name)values(?,?)");
		pstm.setInt(1, id);
		pstm.setString(2, name);
		int i =pstm.executeUpdate();
		System.out.println(i+ " record inserted");
		
	
	

	}

}
