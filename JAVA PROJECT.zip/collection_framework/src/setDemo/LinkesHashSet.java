package setDemo;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkesHashSet {

	public static void main(String[] args) {
		Set langauges = new LinkedHashSet<>();
		langauges.add("C");
		langauges.add("java");
		langauges.add("python");
		langauges.add("C");
		langauges.add(10.5);
		langauges.add(10.5);
		langauges.add("PHP");//linkedHashset Preserved Insertion Orderd
		System.out.println(langauges);
		/*System.out.println(langauges.contains("python"));//true
		System.out.println(langauges.isEmpty());//false
		langauges.remove("PHP");
		System.out.println(langauges);
		System.out.println(langauges.size());
		*/

		for (Object object : langauges) {
			System.out.println(object);
		}
	}

}
