package filehandlingbyIO;

import java.io.File;
import java.io.IOException;

public class Test {
	void creatNewMethode (){
		File file =new File("gokula.tesxt");
		try {
			file.createNewFile();
			System.out.println("file is created");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	//	create a file 
		
		public static void main(String[] args) {
			Test t = new Test();
			t.creatNewMethode();
	}

}
