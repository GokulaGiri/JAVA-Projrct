package hirarchical_inheritance;

public class Parent {
	void m1(){
		System.out.println("Parent class m1 methode ");
	}

}
class Class1 extends Parent{
	void m2(){
		System.out.println("Class1 class m2 methode");
	}
}
class Class2 extends Parent{
	void m3(){
		System.out.println("Class2 class m3 methode");
	}
}
