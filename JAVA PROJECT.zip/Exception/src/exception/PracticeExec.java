package exception;

public class PracticeExec {
	public static void main(String[] args) {
		SayHello();
	}
	public static void  SayHello(){
		SayGoodMorning();
	}
	public static void SayGoodMorning(){
		
		System.out.println("hello All " +" Good Morning");
		System.out.println(10/0);
	}
		
		
}	
		
		
		
		
	


