package com.logicalQuestions;

public class FabonacciSeries {

	public static void main(String[] args) {
		//write a programe of Fabonaccic Series
		
		//  0 1 1 2 3 5 8 13 21 34
	
		int n1=0;
		int n2=1;
		int count =8;
		System.out.println(n1+"\n"+n2);
		for (int i = 0; i < count; i++) {
			int n3=n1+n2;
			System.out.println(n3);
			n1=n2;
			n2=n3;
		}
	}

}
