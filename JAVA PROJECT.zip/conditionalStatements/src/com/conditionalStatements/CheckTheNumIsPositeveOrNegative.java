package com.conditionalStatements;

public class CheckTheNumIsPositeveOrNegative {

	public static void main(String[] args) {
		//int n =-85;//num is negative
		int n =-85;//num is positive
		if(n>0){
			System.out.println("num is positive");
		}
		else{
			System.out.println("num is negative");
		}
	}

}
