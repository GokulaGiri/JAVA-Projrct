package com.javaLogical;

public class PrimeNumber {

	public static void main(String[] args) {
		
		int n=53;
		int sum=0;
		if (n<=1) {
			System.out.println("no is not prime ");
			return;
		}
		for (int i = 2; i <=n-1; i++) {
			if (n%i==0) {
				sum=sum+i;
			}
		}
		if (sum==0) {
			System.out.println("no is prime");
		} else {
System.out.println("no is not prime");
		}
	}}

/*
int n=53;
int sum=0;
if (n<=1) {
	System.out.println("number is not prime");
	return;
}
for (int i = 2; i <=n-1; i++) {
	if (n%i==0) {
		sum=sum+1;
	}
}
if (sum==0) {
	System.out.println("number is Prime");
}else{
	System.out.println("number is not Prime");
}
*/	