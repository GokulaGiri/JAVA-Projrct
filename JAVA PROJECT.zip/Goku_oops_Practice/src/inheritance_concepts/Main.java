package inheritance_concepts;

public class Main {

	public static void main(String[] args) {
		Child  ch = new Child ();
		ch.m1(); // in single inheritance 
		ch.m2();// we call parent classs proprty 
		// by using child refrence

	}

}
