package setsemo_pack;

public class Hashset {

}
