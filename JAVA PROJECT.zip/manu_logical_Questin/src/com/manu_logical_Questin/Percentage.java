package com.manu_logical_Questin;

public class Percentage {

	public static void main(String[] args) {
		double total_Marks=500;
		double per =30;
		double result=total_Marks*(per/100);
		System.out.println(result);

	}

}
