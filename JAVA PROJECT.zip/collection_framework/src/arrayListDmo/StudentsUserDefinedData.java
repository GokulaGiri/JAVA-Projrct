package arrayListDmo;

public class StudentsUserDefinedData {
	
	String name ;
	double Marks;
	int RollNum;
	
	public StudentsUserDefinedData (String name,	double Marks , int RollNum){
		
		this.name=name;
		this.Marks=Marks;
		this.RollNum =RollNum;
		
	}
	
	void disply (){
		System.out.println("Students Name Is :" +name);
		System.out.println("Students Marks Is :" +Marks);
		System.out.println("Students NaRollNumme Is :" +RollNum);
		System.out.println("*****************************************************");
	}
	

}
