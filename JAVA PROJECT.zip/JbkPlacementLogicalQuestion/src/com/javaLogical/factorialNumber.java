package com.javaLogical;

public class factorialNumber {
// factorial numbe means product of one to given number (5), example:= n=5  ,1*2*3*4*5=120
	public static void main(String[] args) {
		int fact =1;
		int n=6;
		for (int i = 1; i <=n; i++) {
		fact=fact*i;
		}
			System.out.println("six factorial is ="+fact);	
	}}