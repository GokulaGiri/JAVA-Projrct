package com.conditionalStatements;

class CalCulatorByUsingIf_ElseIf_Else {

	public static void main(String[] args) {
		int FirstNum = 20;
		int SecondNum = 10;
		//char operator ='%';
		char operator ='+';
		//char operator ='-';
		//char operator ='*';
		//char operator ='/';
		
		
		if(operator=='+'){
			System.out.println(FirstNum+SecondNum);
		}
		else if(operator=='-'){
			System.out.println(FirstNum-SecondNum);
		}
		else if(operator=='*'){
			System.out.println(FirstNum*SecondNum);
		}
		else if(operator=='/'){
			System.out.println(FirstNum/SecondNum);
		}
		else{
			System.out.println("invalid Operator");
		}
		
		
		
		
		
      
	}

}
