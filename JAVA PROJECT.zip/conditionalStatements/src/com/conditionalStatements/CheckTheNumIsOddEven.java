package com.conditionalStatements;

public class CheckTheNumIsOddEven {

	public static void main(String[] args) {

		int n = 7;
		if(n%2==0){
			System.out.println("number is even");
		}
		else{
			System.out.println("number is odd");
		}
	}

}
