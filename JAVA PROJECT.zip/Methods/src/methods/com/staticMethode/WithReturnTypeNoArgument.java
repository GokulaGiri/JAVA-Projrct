package methods.com.staticMethode;

public class WithReturnTypeNoArgument {
	static double  m4 (){
		double a =20;
		double b =30;
		double c =10;
		return (a+b+c);
	}
public static void main(String[] args) {
	//WithReturnTypeNoArgument wr1 = new WithReturnTypeNoArgument();
	double x =WithReturnTypeNoArgument.m4();
	System.out.println(x);
}
}
