package demoOperators;

public class KeywordsINjava
{
int show(int a){
	
	System.out.println(this.show(20));
	return a;
}
	public static void main(String[] args) {
    
		KeywordsINjava r = new KeywordsINjava();
		System.out.println(r);

}
}
