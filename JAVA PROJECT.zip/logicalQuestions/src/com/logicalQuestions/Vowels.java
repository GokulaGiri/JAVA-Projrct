package com.logicalQuestions;

import java.util.Scanner;

public class Vowels {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the Character");
		char ch=sc.next().charAt(0);
		switch(ch){
		case 'a':
		case 'e':
		case 'i':
		case 'o':
		case 'u':
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U':
			System.out.println("The Given Character Is Vowels");
			break;
			default:
			System.out.println("The Given Character is Consonant");
			
		}
		
		
}
}
