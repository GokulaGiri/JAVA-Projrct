package hierarchical_inheritance;

public class Main {
	
	public static void main(String[] args) {
		
		C1 c1 =new C1();
		c1.m1();
		c1.m2();
		
		C2 c2 = new C2();
		c2.m1();
		c2.m2();
		
		
	}
	

}
