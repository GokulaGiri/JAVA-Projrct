package interfacepack;

public interface ATM {
	  void deposit();

	void withdraw();
	
	void checkbalance();

void changepin();

}
class SBIATM implements ATM {
	
	public void deposit(){
		System.out.println("SBIATM deposit methode ");
	}
	public void withdraw(){
		System.out.println("SBIATM withdraw methode ");
	}
	public void checkbalance(){
		System.out.println("SBIATM checkbalance methode ");
	}
	
 
	public void changepin(){
		System.out.println("SBIATM changepin methode ");
	}
}

class CBIATM implements ATM {
	
	public void deposit(){
		System.out.println("CBIATM deposit methode ");
	}
	public void withdraw(){
		System.out.println("CBIATM withdraw methode ");
	}
	public void checkbalance(){
		System.out.println("CBIATM checkbalance methode ");
	}
	
 
	public void changepin(){
		System.out.println("CBIATM changepin methode ");
	}
}
 

