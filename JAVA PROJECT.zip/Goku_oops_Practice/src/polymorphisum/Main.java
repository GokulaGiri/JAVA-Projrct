package polymorphisum;

public class Main {

	public static void main(String[] args) {
		Methode_overloading mr =new Methode_overloading();
		mr.m1(10,20);
mr.m2(10, 30, 30);
	}

}
