package interfacepack;

public class Main {
	public static void main(String[] args) {
		
		
		SBIATM sbi = new SBIATM ();
		
		sbi.changepin();
		sbi.checkbalance();
		sbi.deposit();
		sbi.withdraw();
		
		
		System.out.println("***********************");
		
	CBIATM cbi = new CBIATM ();
		
	cbi.changepin();
	cbi.checkbalance();
	cbi.deposit();
	cbi.withdraw();
		
		
	}

}
